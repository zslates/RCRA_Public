// ==================================================
// RCRA BI PORTAL - CONTENT SCRIPT (FINAL)
// ==================================================

var pendingLayout = { width: '0px', height: '100vh', push: '0px', side: 'left', isFloating: false };
let lastCheckedUrl = ""; 
let urlCheckTimeout;
let isDevBarActive = false;

// ==================================================
// 1. SIDEBAR & LAYOUT LOGIC
// ==================================================
function initSidebar() {
  if (document.getElementById('rcra-sidebar-frame')) return;

  const iframe = document.createElement('iframe');
  iframe.id = 'rcra-sidebar-frame';
  iframe.src = chrome.runtime.getURL('sidebar.html') + '?parent=' + encodeURIComponent(window.location.href);
  
  iframe.style.cssText = `
    position: fixed; top: 0; height: 100vh; border: none; z-index: 2147483648;
    background: transparent !important; color-scheme: normal; transition: all 0.3s ease; 
  `;

  iframe.onload = () => {
    iframe.contentWindow.postMessage({ action: 'REQUEST_LAYOUT' }, '*');
  };

  document.documentElement.appendChild(iframe);
  checkWelcomeStatus();
}

function applyLayout(data) {
    if (data) pendingLayout = { ...data };
    
    const frame = document.getElementById('rcra-sidebar-frame');
    const htmlNode = document.documentElement;
    const topOffset = isDevBarActive ? '40px' : '0px';

    if (frame) {
        frame.style.width = pendingLayout.width;
        frame.style.height = isDevBarActive ? `calc(100vh - 40px)` : pendingLayout.height;
        frame.style.top = topOffset;
        frame.style.boxShadow = pendingLayout.isFloating ? 'none' : '0 0 10px rgba(0,0,0,0.2)';

        if (pendingLayout.side === 'left') {
            frame.style.left = '0'; frame.style.right = 'auto';
            frame.style.borderRight = '1px solid rgba(0,0,0,0.1)'; frame.style.borderLeft = 'none';
        } else {
            frame.style.right = '0'; frame.style.left = 'auto';
            frame.style.borderLeft = '1px solid rgba(0,0,0,0.1)'; frame.style.borderRight = 'none';
        }
    }

    if (htmlNode) {
        htmlNode.style.transition = 'margin 0.3s ease';
        htmlNode.style.marginTop = topOffset;
        if (pendingLayout.side === 'left') {
            htmlNode.style.marginLeft = pendingLayout.push;
            htmlNode.style.marginRight = '0px';
        } else {
            htmlNode.style.marginRight = pendingLayout.push;
            htmlNode.style.marginLeft = '0px';
        }
    }
}

// ==================================================
// 2. DEV TOP BAR LOGIC
// ==================================================
async function showDevBar() {
    if (isDevBarActive) return;
    
    let container = document.getElementById('rcra-dev-wrapper');
    if (!container) {
        const response = await fetch(chrome.runtime.getURL('dev_bar.html'));
        const htmlContent = await response.text();
        
        container = document.createElement('div');
        container.id = "rcra-dev-wrapper";
        container.innerHTML = htmlContent;
        document.body.prepend(container);

        setTimeout(() => {
            const btnClose = document.getElementById('rcra-bar-close');
            if (btnClose) btnClose.addEventListener('click', removeDevBar);
        }, 100);
    }

    setTimeout(() => {
        const bar = document.getElementById('rcra-dev-bar');
        if (bar) bar.classList.add('visible');
    }, 50);

    isDevBarActive = true;
    applyLayout(); 
}

function removeDevBar() {
    if (!isDevBarActive) return;
    const bar = document.getElementById('rcra-dev-bar');
    if (bar) bar.classList.remove('visible');
    isDevBarActive = false;
    applyLayout();
    setTimeout(() => {
        const wrapper = document.getElementById('rcra-dev-wrapper');
        if (wrapper) wrapper.remove();
    }, 300);
}

// ==================================================
// 3. AUTOMATIC URL MONITOR
// ==================================================
async function checkCurrentUrlForDevFlag() {
    const browserUrl = window.location.href.toLowerCase();
    
    const getReportId = (url) => {
        const match = url.match(/reports\/([a-f0-9\-]{36})/);
        return match ? match[1] : url.split('?')[0]; 
    };

    const currentId = getReportId(browserUrl);
    if (currentId === lastCheckedUrl) return; 
    lastCheckedUrl = currentId;

    const data = await chrome.storage.local.get('cachedMenu');
    let matchFound = false;

    if (data && data.cachedMenu) {
        const scanMenu = (items) => {
            for (const item of items) {
                if (item.url) {
                    const menuId = getReportId(item.url.toLowerCase());
                    if (currentId.includes(menuId) || menuId.includes(currentId)) {
                        if (item.inDevelopment === true || item.inDevelopment === "true") {
                            matchFound = true;
                            break;
                        }
                    }
                }
                if (!matchFound && item.items) scanMenu(item.items);
            }
        };
        scanMenu(data.cachedMenu);
    }

    if (matchFound) {
        console.log("RCRA: Development Report Detected - Showing Bar");
        showDevBar();
    } else {
        if (isDevBarActive) removeDevBar();
    }
}

// Watch for SPA navigation (Title changes)
const urlObserver = new MutationObserver(() => {
    clearTimeout(urlCheckTimeout);
    urlCheckTimeout = setTimeout(checkCurrentUrlForDevFlag, 2000); 
});

urlObserver.observe(document.querySelector('title') || document.documentElement, { 
    subtree: true, 
    childList: true 
});


// ==================================================
// 4. AGGRESSIVE FAVICON ENFORCER (FIXED)
// ==================================================
function forceFavicon() {
    const iconUrl = chrome.runtime.getURL("icon48.png");
    
    // Find ALL icon links (shortcut icon, icon, apple-touch-icon, etc.)
    const links = document.querySelectorAll("link[rel*='icon']");
    
    let found = false;
    links.forEach(link => {
        if (link.href !== iconUrl) {
            link.href = iconUrl; // Overwrite existing
        }
        found = true;
    });

    // If Power BI deleted the link entirely, create a new one
    if (!found) {
        const link = document.createElement('link');
        link.type = 'image/png';
        link.rel = 'icon';
        link.href = iconUrl;
        document.head.appendChild(link);
    }
}

// Watch the <HEAD> for changes. If Power BI puts its yellow icon back, we swap it immediately.
const faviconObserver = new MutationObserver(() => {
    forceFavicon();
});

faviconObserver.observe(document.head, { 
    subtree: true, 
    childList: true, 
    attributes: true, 
    attributeFilter: ['href', 'rel'] // Only care if link attributes change
});

// Run immediately
forceFavicon();


// ==================================================
// 5. UTILITIES & INIT
// ==================================================

async function checkWelcomeStatus() {
    const data = await chrome.storage.local.get('welcomeDismissed');
    if (data.welcomeDismissed) return;
    createWelcomeOverlay();
}

async function createWelcomeOverlay() {
    if (document.getElementById('rcra-welcome-container')) return;
    const response = await fetch(chrome.runtime.getURL('welcome.html'));
    const htmlContent = await response.text();
    const container = document.createElement('div');
    container.id = 'rcra-welcome-container';
    container.innerHTML = htmlContent;
    document.body.appendChild(container);

    setTimeout(() => {
        const closeBtn = document.getElementById('rcra-close-btn');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                const checkbox = document.getElementById('rcra-dont-show');
                if (checkbox && checkbox.checked) {
                    chrome.storage.local.set({ welcomeDismissed: true });
                }
                const overlay = document.getElementById('rcra-welcome-overlay');
                if (overlay) {
                    overlay.style.opacity = '0';
                    setTimeout(() => container.remove(), 300);
                }
            });
        }
    }, 100);
}

if (document.documentElement) {
  initSidebar();
  setTimeout(checkCurrentUrlForDevFlag, 2500);
  
  // Set up an interval just in case the observer misses a weird PBI update
  setInterval(forceFavicon, 5000);
}

window.addEventListener('load', () => {
    if (pendingLayout.width !== '0px') applyLayout();
});

window.addEventListener('message', (event) => {
    if (event.data.action === 'UPDATE_LAYOUT') applyLayout(event.data);
});

chrome.runtime.onMessage.addListener((request) => {
    if (request.action === 'REMOVE_SIDEBAR') {
        const frame = document.getElementById('rcra-sidebar-frame');
        if (frame) frame.remove();
        document.documentElement.style.marginLeft = '0px';
        document.documentElement.style.marginTop = '0px';
        isDevBarActive = false;
        removeDevBar();
    }
    if (request.action === 'OPEN_SIDEBAR') initSidebar();
});