// ==========================================
// RCRA MENU EDITOR - MAIN LOGIC
// ==========================================

// Global State
let rootData = [];
let selectedPath = null;
let currentSha = null;
let dragSrcPath = null; 

// --- INIT ---
document.addEventListener('DOMContentLoaded', () => {
    console.log("Admin Editor Loaded");

    // Load saved GitHub creds
    const owner = localStorage.getItem('gh_owner');
    const repo = localStorage.getItem('gh_repo');
    const path = localStorage.getItem('gh_path');
    const token = localStorage.getItem('gh_token');

    if(owner) document.getElementById('gh-owner').value = owner;
    if(repo) document.getElementById('gh-repo').value = repo;
    if(path) document.getElementById('gh-path').value = path;
    if(token) document.getElementById('gh-token').value = token;

    // Attach Listeners
    document.getElementById('btn-save-creds').addEventListener('click', saveCreds);
    document.getElementById('btn-load').addEventListener('click', loadFromCloud);
    document.getElementById('btn-publish').addEventListener('click', publishToCloud);
    document.getElementById('btn-add-root').addEventListener('click', () => addItem(true));
    document.getElementById('btn-update').addEventListener('click', updateItem);
    document.getElementById('btn-delete').addEventListener('click', deleteItem);
    document.getElementById('inp-type').addEventListener('change', toggleUI);
    
    // Bottom Bar Buttons
    document.getElementById('btn-add-sub-folder').addEventListener('click', () => addItem(false, 'folder'));
    document.getElementById('btn-add-sub-link').addEventListener('click', () => addItem(false, 'report'));
    
    document.getElementById('btn-up').addEventListener('click', () => moveItem(-1));
    document.getElementById('btn-down').addEventListener('click', () => moveItem(1));

    // Auto-load if creds exist
    if (token && owner && repo) {
        loadFromCloud();
    } else {
        toast("System Ready - Please set GitHub Credentials");
    }
});

// ==========================================
// GITHUB ACTIONS
// ==========================================
async function saveCreds() {
    const owner = document.getElementById('gh-owner').value.trim();
    const repo = document.getElementById('gh-repo').value.trim();
    const path = document.getElementById('gh-path').value.trim();
    const token = document.getElementById('gh-token').value.trim();
    
    // 1. Save locally
    localStorage.setItem('gh_owner', owner);
    localStorage.setItem('gh_repo', repo);
    localStorage.setItem('gh_path', path);
    localStorage.setItem('gh_token', token);

    // 2. VISUAL FEEDBACK: Start Test
    const statusEl = document.getElementById('gh-status');
    statusEl.innerHTML = '⏳ Testing Connection...';
    statusEl.className = 'status-msg active';
    
    if(!token || !owner || !repo) {
        statusEl.innerHTML = '❌ Missing Fields';
        statusEl.classList.add('error');
        return;
    }

    // 3. ACTUAL NETWORK TEST
    try {
        const url = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;
        
        const res = await fetch(url + '?t=' + new Date().getTime(), { 
            method: 'GET',
            headers: { Authorization: `token ${token}` } 
        });
        
        if(res.ok) {
            statusEl.innerHTML = '✅ Connection Verified!';
            statusEl.classList.add('success');
            setTimeout(() => {
               document.getElementById('details-settings').removeAttribute('open');
               statusEl.classList.remove('active');
            }, 1500);

            if (rootData.length === 0) loadFromCloud();
            else toast("Credentials Saved & Verified");

        } else {
            throw new Error(`GitHub Error: ${res.status} (${res.statusText})`);
        }
    } catch(e) {
        statusEl.innerHTML = `❌ Failed: ${e.message}`;
        statusEl.classList.add('error');
    }
}

async function loadFromCloud() {
    const token = document.getElementById('gh-token').value.trim();
    const owner = document.getElementById('gh-owner').value.trim();
    const repo = document.getElementById('gh-repo').value.trim();
    const path = document.getElementById('gh-path').value.trim();

    if(!token || !owner) return toast("⚠️ Check Settings");

    toast("⏳ Loading...");
    const url = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;

    try {
        const res = await fetch(url + '?t=' + new Date().getTime(), { 
            headers: { Authorization: `token ${token}` } 
        });
        
        if(!res.ok) throw new Error(res.status);
        
        const data = await res.json();
        currentSha = data.sha;
        const json = decodeURIComponent(escape(window.atob(data.content)));
        rootData = JSON.parse(json);
        
        renderTree();
        toast("✅ Loaded");
        
        document.getElementById('editor-ui').style.display = 'none';
        document.getElementById('empty-msg').style.display = 'flex';

    } catch(e) {
        alert("Load Error: " + e.message);
    }
}

async function publishToCloud() {
    if(!currentSha) return alert("You must LOAD first to get the SHA.");
    if(!confirm("Publish changes live to Power BI users?")) return;

    const token = document.getElementById('gh-token').value.trim();
    const owner = document.getElementById('gh-owner').value.trim();
    const repo = document.getElementById('gh-repo').value.trim();
    const path = document.getElementById('gh-path').value.trim();

    toast("⏳ Publishing...");
    
    // CLEANUP: Remove _expanded and _moveId flags before saving to cloud
    const cleanData = (items) => {
        return items.map(item => {
            const newItem = { ...item };
            delete newItem._expanded; // Don't save expansion state to server
            delete newItem._moveId;
            if (newItem.items) {
                newItem.items = cleanData(newItem.items);
            }
            return newItem;
        });
    };

    const payloadData = cleanData(rootData);
    const url = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;
    const content = JSON.stringify(payloadData, null, 2);
    const encoded = window.btoa(unescape(encodeURIComponent(content)));

    try {
        const res = await fetch(url, {
            method: 'PUT',
            headers: { Authorization: `token ${token}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: "Update via Admin Tool", content: encoded, sha: currentSha })
        });
        
        if(!res.ok) throw new Error(res.statusText);
        const data = await res.json();
        currentSha = data.content.sha;
        toast("🚀 Published Successfully!");
    } catch(e) {
        alert("Publish Error: " + e.message);
    }
}

// ==========================================
// TREE RENDERER (Uses Data State)
// ==========================================
function renderTree() {
    const container = document.getElementById('tree-root');
    container.innerHTML = '';

    function buildNode(item, path) {
        const wrapper = document.createElement('div');
        
        // Only add 'expanded' class if data says so. Default is closed.
        if (item._expanded) {
            wrapper.className = 'expanded';
        }

        const nodeDiv = document.createElement('div');
        
        const isSel = selectedPath && JSON.stringify(path) === JSON.stringify(selectedPath);
        const isFolder = item.items !== undefined;
        const hasKids = isFolder && item.items.length > 0;

        // Apply Warning Style if In Development
        let classes = 'node ' + (isSel ? 'selected' : '');
        if (item.inDevelopment === true) classes += ' dev-flag';
        nodeDiv.className = classes;
        
        nodeDiv.draggable = true;
        
        const label = item.category || item.name || 'Untitled';
        
        // 1. Expansion Arrow
        const arrowSpan = document.createElement('span');
        arrowSpan.className = 'toggle-icon';
        arrowSpan.style.pointerEvents = 'auto'; 
        arrowSpan.style.marginRight = '5px';
        
        if (isFolder) {
            arrowSpan.innerText = item._expanded ? '▼' : '▶'; 
            arrowSpan.onclick = (e) => {
                e.stopPropagation(); 
                
                // SAVE STATE TO DATA MODEL
                item._expanded = !item._expanded;
                
                // Update DOM immediately
                if (item._expanded) {
                    wrapper.classList.add('expanded');
                    arrowSpan.innerText = '▼';
                } else {
                    wrapper.classList.remove('expanded');
                    arrowSpan.innerText = '▶';
                }
            };
        } else {
            arrowSpan.innerText = ''; // No arrow for links
        }

        // 2. Icon & Label
        let iconChar = '🔗';
        if (isFolder) iconChar = '📁';
        else if (item.linkType === 'excel') iconChar = '📗';
        
        // ADDED: Show construction icon if flagged
        if (item.inDevelopment === true) iconChar = '🚧 ' + iconChar;

        const textSpan = document.createElement('span');
        textSpan.innerText = `${iconChar} ${label}`;
        
        nodeDiv.appendChild(arrowSpan);
        nodeDiv.appendChild(textSpan);

        // --- HOVER ACTIONS (Tree Buttons) ---
        if (isFolder) {
            const actionsDiv = document.createElement('div');
            actionsDiv.className = 'node-actions';
            
            const plusBtn = document.createElement('div');
            plusBtn.className = 'action-btn btn-plus';
            plusBtn.title = "Add Child Item";
            
            const expandGroup = document.createElement('div');
            expandGroup.style.display = 'none';
            expandGroup.style.gap = '4px';

            const addLinkBtn = document.createElement('div');
            addLinkBtn.className = 'action-btn btn-add-link';
            addLinkBtn.title = "Add Link";
            
            const addFolderBtn = document.createElement('div');
            addFolderBtn.className = 'action-btn btn-add-folder';
            addFolderBtn.title = "Add Folder";

            plusBtn.onclick = (e) => {
                e.stopPropagation();
                plusBtn.style.display = 'none';
                expandGroup.style.display = 'flex';
                expandGroup.classList.add('actions-expanded');
                actionsDiv.classList.add('active'); 
            };

            addLinkBtn.onclick = (e) => { e.stopPropagation(); addItemToPath(path, 'report'); };
            addFolderBtn.onclick = (e) => { e.stopPropagation(); addItemToPath(path, 'folder'); };

            expandGroup.appendChild(addFolderBtn);
            expandGroup.appendChild(addLinkBtn);
            actionsDiv.appendChild(plusBtn);
            actionsDiv.appendChild(expandGroup);

            nodeDiv.addEventListener('mouseleave', () => {
                plusBtn.style.display = 'flex';
                expandGroup.style.display = 'none';
                actionsDiv.classList.remove('active');
            });

            nodeDiv.appendChild(actionsDiv);
        }

        nodeDiv.addEventListener('click', (e) => { 
            e.stopPropagation(); 
            select(path); 
        });

        // --- DRAG EVENTS ---
        nodeDiv.addEventListener('dragstart', (e) => {
            e.stopPropagation();
            dragSrcPath = path;
            e.dataTransfer.effectAllowed = 'move';
            nodeDiv.style.opacity = '0.5';
        });

        nodeDiv.addEventListener('dragend', () => {
            nodeDiv.style.opacity = '1';
            clearDragClasses();
        });

        nodeDiv.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.stopPropagation();
            clearDragClasses();

            const rect = nodeDiv.getBoundingClientRect();
            const relY = e.clientY - rect.top;
            const height = rect.height;
            
            if (relY < height * 0.25) {
                nodeDiv.classList.add('drop-above');
                nodeDiv.style.borderTop = "2px solid #9575cd";
            } else if (relY > height * 0.75) {
                nodeDiv.classList.add('drop-below');
                nodeDiv.style.borderBottom = "2px solid #9575cd";
            } else {
                if (isFolder) {
                    nodeDiv.classList.add('drop-inside');
                    nodeDiv.style.background = "rgba(149, 117, 205, 0.3)";
                } else {
                    nodeDiv.classList.add('drop-below');
                    nodeDiv.style.borderBottom = "2px solid #9575cd";
                }
            }
        });

        nodeDiv.addEventListener('dragleave', () => {
             clearDragClasses();
        });

        nodeDiv.addEventListener('drop', (e) => {
            e.stopPropagation();
            e.preventDefault();
            
            let action = 'inside';
            if (nodeDiv.classList.contains('drop-above')) action = 'above';
            else if (nodeDiv.classList.contains('drop-below')) action = 'below';
            
            clearDragClasses();
            handleDrop(path, action);
        });

        wrapper.appendChild(nodeDiv);

        if(hasKids) {
            const kidsBox = document.createElement('div');
            kidsBox.className = 'children'; 
            item.items.forEach((k, i) => {
                kidsBox.appendChild(buildNode(k, [...path, i]));
            });
            wrapper.appendChild(kidsBox);
        }
        return wrapper;
    }

    rootData.forEach((item, i) => container.appendChild(buildNode(item, [i])));
}

function clearDragClasses() {
    document.querySelectorAll('.node').forEach(el => {
        el.style.borderTop = "none";
        el.style.borderBottom = "none";
        if (!el.classList.contains('selected')) {
            el.style.background = "";
        } else {
            el.style.background = "rgba(149, 117, 205, 0.15)";
        }
        el.classList.remove('drop-above', 'drop-below', 'drop-inside');
    });
}

function handleDrop(targetPath, action) {
    if (!dragSrcPath) return;
    if (JSON.stringify(dragSrcPath) === JSON.stringify(targetPath)) return;

    // 1. Get Source
    let srcParent = rootData;
    if (dragSrcPath.length > 1) {
        for(let i=0; i<dragSrcPath.length-1; i++) srcParent = srcParent[dragSrcPath[i]].items;
    }
    const srcIndex = dragSrcPath[dragSrcPath.length-1];
    const itemToMove = srcParent[srcIndex];

    const uniqueId = Date.now() + Math.random();
    itemToMove._moveId = uniqueId;
    
    // NOTE: This copy preserves _expanded state!
    const clonedItem = JSON.parse(JSON.stringify(itemToMove));
    delete clonedItem._moveId; 

    // 2. Insert into Dest
    let destNode = rootData[targetPath[0]];
    for(let i=1; i<targetPath.length; i++) destNode = destNode.items[targetPath[i]];

    let isBecomingRoot = false;

    if (action === 'inside') {
        isBecomingRoot = false;
        if(!destNode.items) destNode.items = [];
        destNode.items.push(clonedItem);
        // Force expand the destination folder so user sees where it went
        destNode._expanded = true;
    } else {
        if (targetPath.length === 1) isBecomingRoot = true;
        
        let destParent = rootData;
        if (targetPath.length > 1) {
            for(let i=0; i<targetPath.length-1; i++) destParent = destParent[targetPath[i]].items;
        }
        const destIndex = targetPath[targetPath.length-1];
        const insertAt = action === 'above' ? destIndex : destIndex + 1;
        destParent.splice(insertAt, 0, clonedItem);
    }

    // 3. Fix Keys
    if (isBecomingRoot) {
        if (clonedItem.name && !clonedItem.category) {
            clonedItem.category = clonedItem.name;
            delete clonedItem.name;
        }
    } else {
        if (clonedItem.category && !clonedItem.name) {
            clonedItem.name = clonedItem.category;
            delete clonedItem.category;
        }
    }

    // 4. Cleanup
    deleteById(rootData, uniqueId);
    delete itemToMove._moveId; 

    dragSrcPath = null;
    selectedPath = null;
    renderTree();
    toast("Moved & Saved State");
}

function deleteById(items, id) {
    for (let i = 0; i < items.length; i++) {
        if (items[i]._moveId === id) {
            items.splice(i, 1);
            return true;
        }
        if (items[i].items) {
            if (deleteById(items[i].items, id)) return true;
        }
    }
    return false;
}

// ==========================================
// EDITOR ACTIONS
// ==========================================
function select(path) {
    selectedPath = path;
    renderTree();
    
    let node = rootData[path[0]];
    for(let i=1; i<path.length; i++) node = node.items[path[i]];

    document.getElementById('editor-ui').style.display = 'block';
    document.getElementById('empty-msg').style.display = 'none';
    
    const isFolder = node.items !== undefined;
    document.getElementById('inp-type').value = isFolder ? 'folder' : 'report';
    document.getElementById('inp-name').value = node.category || node.name || "";
    document.getElementById('inp-url').value = node.url || "";
    
    const linkTypeEl = document.getElementById('inp-link-type');
    if (linkTypeEl) linkTypeEl.value = node.linkType || 'report';
    
    // --- LOAD DEV FLAG (ADDED) ---
    const devBox = document.getElementById('inp-dev');
    if (devBox) devBox.checked = node.inDevelopment === true;
    
    toggleUI();
}

function updateItem() {
    if(!selectedPath) return;
    const { parent, index } = getParentAndIndex(selectedPath);
    const node = parent[index];
    const name = document.getElementById('inp-name').value;
    const type = document.getElementById('inp-type').value;

    if(selectedPath.length === 1) { 
        node.category = name; delete node.name; 
    } else { 
        node.name = name; delete node.category; 
    }

    if(type === 'report') {
        const inputUrl = document.getElementById('inp-url').value.trim();
        // VALIDATION REMOVED HERE
        node.url = inputUrl;
        
        const linkTypeEl = document.getElementById('inp-link-type');
        if (linkTypeEl) node.linkType = linkTypeEl.value;
        
        // --- SAVE DEV FLAG (ADDED) ---
        const devBox = document.getElementById('inp-dev');
        if (devBox) node.inDevelopment = devBox.checked;
        
        delete node.items;
    } else {
        delete node.url;
        delete node.linkType; 
        delete node.inDevelopment; // Clean up flag if converting to folder
        if(!node.items) node.items = [];
    }
    renderTree();
    toast("Saved Successfully");
}

function addItem(isRoot, type) {
    if(isRoot) {
        rootData.push({ category: "New Root", items: [] });
        select([rootData.length-1]);
    } else {
        if (!selectedPath) return toast("Select a folder first");
        addItemToPath(selectedPath, type);
    }
}

function addItemToPath(parentPath, type) {
    let node = rootData[parentPath[0]];
    for(let i=1; i<parentPath.length; i++) node = node.items[parentPath[i]];

    if(!node.items) node.items = [];
    
    // Auto-expand folder when adding child
    node._expanded = true;

    const newItem = type === 'folder' 
        ? { name: "New Folder", items: [] } 
        : { name: "New Link", url: "", linkType: "report" };
            
    const newIndex = node.items.push(newItem) - 1;
    const newPath = [...parentPath, newIndex];
    
    renderTree();
    select(newPath); 
    toast(`Added new ${type}`);
}

function deleteItem() {
    if(!confirm("Are you sure you want to delete this item?")) return;
    const { parent, index } = getParentAndIndex(selectedPath);
    parent.splice(index, 1);
    selectedPath = null;
    
    document.getElementById('editor-ui').style.display = 'none';
    document.getElementById('empty-msg').style.display = 'flex';
    
    renderTree();
    toast("Item Deleted");
}

function moveItem(dir) {
    if(!selectedPath) return;
    const { parent, index } = getParentAndIndex(selectedPath);
    const newIdx = index + dir;
    if(newIdx >= 0 && newIdx < parent.length) {
        [parent[index], parent[newIdx]] = [parent[newIdx], parent[index]];
        selectedPath[selectedPath.length-1] = newIdx;
        renderTree();
    }
}

function getParentAndIndex(path) {
    let parent = rootData;
    if(path.length > 1) {
        for(let i=0; i<path.length-1; i++) parent = parent[path[i]].items;
    }
    return { parent, index: path[path.length-1] };
}

function toggleUI() {
    const isFolder = document.getElementById('inp-type').value === 'folder';
    document.getElementById('box-url').style.display = isFolder ? 'none' : 'grid';
}

function toast(msg) {
    const t = document.getElementById('toast');
    t.innerText = msg;
    t.style.display = 'block';
    setTimeout(() => t.style.display = 'none', 3000);
}