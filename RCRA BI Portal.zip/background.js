// ==================================================
// RCRA BI PORTAL - BACKGROUND SERVICE WORKER
// ==================================================

// Config: Needs to match sidebar.js
const MENU_URL = 'https://raw.githubusercontent.com/zslates/RCRA_Public/main/menu2.json';
const DEFAULT_HOME = "https://app.powerbi.com/home";

// ==========================================
// 1. HELPER: DYNAMIC HOME URL
// ==========================================
async function getDynamicHomeUrl() {
  try {
    // A. Check Cache First (Fast)
    const stored = await chrome.storage.local.get('cachedMenu');
    let data = stored.cachedMenu;

    // B. If no cache, fetch live (Slow but necessary for first run)
    if (!data || data.length === 0) {
       const res = await fetch(MENU_URL);
       data = await res.json();
       // Cache it for next time
       await chrome.storage.local.set({ cachedMenu: data });
    }

    // C. Helper to find first link recursively
    const findFirstLink = (items) => {
        for (const item of items) {
            // If it's a link with a URL, return it
            if (item.url && item.url !== "#") return item.url;
            // If it's a folder, dig inside
            if (item.items && item.items.length > 0) {
                const found = findFirstLink(item.items);
                if (found) return found;
            }
        }
        return null;
    };

    const firstUrl = findFirstLink(data);
    
    // D. Ensure it's a full URL
    if (firstUrl) {
         if (!firstUrl.startsWith('http') && !firstUrl.startsWith('//')) {
             return DEFAULT_HOME; 
         }
         return firstUrl;
    }

  } catch (e) {
    console.warn("Failed to determine dynamic home, using default.", e);
  }
  return DEFAULT_HOME;
}

// ==========================================
// 2. LISTENER: IDENTITY REQUESTS (NEW)
// ==========================================
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'GET_USER_IDENTITY') {
        // Ask the browser: "Who is logged into this profile?"
        // This requires the "identity" permission in manifest.json
        chrome.identity.getProfileUserInfo((userInfo) => {
            // userInfo contains { email: "...", id: "..." }
            sendResponse({ email: userInfo.email || "" });
        });
        return true; // Keeps the message channel open for the async response
    }
});

// ==========================================
// 3. LISTENER: ON INSTALL (SMART HOME)
// ==========================================
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === "install") {
    const targetUrl = await getDynamicHomeUrl();
    chrome.tabs.create({ url: targetUrl });
    chrome.storage.local.set({ isSidebarOpen: true });
  }
});

// ==========================================
// 4. LISTENER: TOGGLE CLICK (MERGED LOGIC)
// ==========================================
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.url.includes("app.powerbi.com")) return;

  const data = await chrome.storage.local.get('isSidebarOpen');
  const newState = !data.isSidebarOpen;
  await chrome.storage.local.set({ isSidebarOpen: newState });

  if (newState) {
    // === TURN ON ===
    const homeUrl = await getDynamicHomeUrl();
    
    // Check if we are already on the "Home" page
    const currentClean = tab.url.toLowerCase().replace(/\/$/, "");
    const homeClean = homeUrl.toLowerCase().replace(/\/$/, "");
    
    if (!currentClean.includes(homeClean)) {
        // Navigate to Smart Home
        await chrome.tabs.update(tab.id, { url: homeUrl });
    } else {
        // Already there? Wake up the sidebar.
        try {
            await chrome.tabs.sendMessage(tab.id, { action: 'OPEN_SIDEBAR' });
        } catch (err) {
            // Script dead or not there? Inject it.
            injectSidebar(tab.id);
        }
    }
  } else {
    // === TURN OFF ===
    try {
      await chrome.tabs.sendMessage(tab.id, { action: 'REMOVE_SIDEBAR' });
    } catch (err) { }
  }
});

// ==========================================
// 5. LISTENER: PAGE NAVIGATION
// ==========================================
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading') {
    const data = await chrome.storage.local.get('isSidebarOpen');
    
    if (data.isSidebarOpen && tab.url && tab.url.startsWith('https://app.powerbi.com/')) {
        injectSidebar(tabId);
    }
  }
});

// Helper Function
function injectSidebar(tabId) {
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ['content.js']
    }).catch(() => {});
}