// ==========================================
// 1. CONFIGURATION
// ==========================================
const MENU_URL = 'https://raw.githubusercontent.com/zslates/RCRA_Public/main/menu2.json';

// ==========================================
// 2. INITIALIZATION & LOGIC
// ==========================================

document.addEventListener('DOMContentLoaded', () => {
  initSidebar();
  initMenu();
});

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') {
    initMenu();
  }
});

function initSidebar() {
  const body = document.body;
  const toggleBtn = document.getElementById('sidebar-toggle');
  const hideBtn = document.getElementById('hide-sidebar-btn');
  const floatIcon = document.getElementById('floating-icon');
  
  const btnLeft = document.getElementById('btn-left');
  const btnRight = document.getElementById('btn-right');

  // --- LAYOUT LOGIC ---
  const updateParentLayout = () => {
    const isFloating = body.classList.contains('floating-mode');
    const isMini = body.classList.contains('mini-mode');
    
    // FORCE LEFT DEFAULT: If no setting exists, use 'left'
    const side = localStorage.getItem('sidebar-side') || 'left';
    
    let frameWidth, frameHeight, pagePush;

    if (isFloating) {
        frameWidth = '60px';   
        frameHeight = '60px';  
        pagePush = '0px';      
    } else {
        frameWidth = isMini ? '65px' : '300px';
        frameHeight = '100vh'; 
        pagePush = frameWidth; 
    }

    window.parent.postMessage({ 
      action: 'UPDATE_LAYOUT', 
      width: frameWidth,
      height: frameHeight,
      push: pagePush,
      side: side,
      isFloating: isFloating 
    }, '*');
  };

  // --- EVENT LISTENERS ---
  if (toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      body.classList.toggle('mini-mode');
      localStorage.setItem('sidebar-mini', body.classList.contains('mini-mode'));
      updateParentLayout();
    });
  }

  if (hideBtn) {
      hideBtn.addEventListener('click', () => {
          body.classList.add('floating-mode');
          localStorage.setItem('sidebar-floating', 'true');
          updateParentLayout();
      });
  }

  if (floatIcon) {
      floatIcon.addEventListener('click', () => {
          body.classList.remove('floating-mode');
          localStorage.setItem('sidebar-floating', 'false');
          body.classList.remove('mini-mode');
          localStorage.setItem('sidebar-mini', 'false'); 
          updateParentLayout();
      });
  }

  const setSide = (side) => {
    localStorage.setItem('sidebar-side', side);
    if (btnLeft && btnRight) {
        if (side === 'left') {
          btnLeft.style.background = '#6a4c93'; btnLeft.style.color = 'white';
          btnRight.style.background = 'rgba(0,0,0,0.2)'; btnRight.style.color = '#aea0c0';
        } else {
          btnRight.style.background = '#6a4c93'; btnRight.style.color = 'white';
          btnLeft.style.background = 'rgba(0,0,0,0.2)'; btnLeft.style.color = '#aea0c0';
        }
    }
    updateParentLayout();
  };

  if (btnLeft && btnRight) {
    btnLeft.addEventListener('click', () => setSide('left'));
    btnRight.addEventListener('click', () => setSide('right'));
  }

  if (localStorage.getItem('sidebar-floating') === 'true') {
      body.classList.add('floating-mode');
  } else if (localStorage.getItem('sidebar-mini') === 'true' || localStorage.getItem('sidebar-mini') === null) {
      body.classList.add('mini-mode');
      if (localStorage.getItem('sidebar-mini') === null) localStorage.setItem('sidebar-mini', 'true');
  }
  
  // INITIALIZE SIDE
  const savedSide = localStorage.getItem('sidebar-side') || 'left';
  setSide(savedSide);

  window.addEventListener('message', (event) => {
    if (event.data.action === 'REQUEST_LAYOUT') {
      updateParentLayout();
    }
  });
}

// ==========================================
// FAVORITES LOGIC
// ==========================================

async function getFavorites() {
    const result = await chrome.storage.local.get('rcraFavorites');
    return result.rcraFavorites || [];
}

async function toggleFavorite(url) {
    if (!url) return;
    let favs = await getFavorites();
    
    if (favs.includes(url)) {
        favs = favs.filter(u => u !== url); 
    } else {
        favs.push(url); 
    }
    
    await chrome.storage.local.set({ rcraFavorites: favs });
    initMenu(); 
}

function findItemByUrl(items, url) {
    for (const item of items) {
        if (item.url === url) return item;
        if (item.items && item.items.length > 0) {
            const found = findItemByUrl(item.items, url);
            if (found) return found;
        }
    }
    return null;
}

// ==========================================
// INIT MENU
// ==========================================
async function initMenu() {
  const container = document.getElementById('nav-tree-container');
  
  let currentData = [];

  try {
    const stored = await chrome.storage.local.get('cachedMenu');
    if (stored.cachedMenu) currentData = stored.cachedMenu;
  } catch (e) {}

  try {
    const response = await fetch(MENU_URL + '?t=' + new Date().getTime());
    if (response.ok) {
        const liveData = await response.json();
        if (JSON.stringify(liveData) !== JSON.stringify(currentData)) {
            currentData = liveData;
            await chrome.storage.local.set({ cachedMenu: liveData });
        }
    }
  } catch (e) { console.warn("Fetch failed, using cache"); }

  const favs = await getFavorites();
  let finalData = JSON.parse(JSON.stringify(currentData)); 

  if (favs.length > 0) {
      const favItems = [];
      favs.forEach(favUrl => {
          const original = findItemByUrl(finalData, favUrl);
          if (original) {
              favItems.push({ ...original }); 
          }
      });

      if (favItems.length > 0) {
          const favFolder = {
              name: "Favorites",
              category: "Favorites",
              items: favItems,
              _isFavFolder: true 
          };
          finalData.unshift(favFolder); 
      }
  }

  renderMenu(finalData, container, favs);
}

// ==========================================
// 3. RENDER LOGIC
// ==========================================
function renderMenu(menuData, container, favoritesList) {
  container.innerHTML = '';
  const urlParams = new URLSearchParams(window.location.search);
  const rawParentUrl = urlParams.get('parent') || '';
  const currentUrl = rawParentUrl.toLowerCase().replace(/\/$/, "");

  function buildNode(item, isRoot) {
    const labelText = isRoot ? (item.category || item.name) : item.name;
    const hasChildren = item.items && Array.isArray(item.items);
    const isFolder = (item.items !== undefined); 
    const isFavFolder = item._isFavFolder === true;
    
    // Check Dev Flag (handle boolean or string)
    const isDev = (item.inDevelopment === true || item.inDevelopment === "true");

    const itemDiv = document.createElement('div');
    let isActive = false;
    
    if (item.url) {
        let itemUrlFull = item.url;
        if (!itemUrlFull.startsWith('http') && !itemUrlFull.startsWith('//') && !itemUrlFull.startsWith('chrome')) {
             itemUrlFull = chrome.runtime.getURL(itemUrlFull);
        }
        const cleanItemUrl = itemUrlFull.toLowerCase().replace(/\/$/, "");
        if (cleanItemUrl.length > 5 && currentUrl.includes(cleanItemUrl)) {
            isActive = true;
        }
    }
    const activeClass = isActive ? 'active-selection' : '';

    if (isFolder) {
        itemDiv.className = 'nav-group';
        if (isFavFolder) itemDiv.classList.add('fav-group');

        itemDiv.setAttribute('data-search-label', labelText.toLowerCase());
        
        const header = document.createElement('div');
        header.className = 'nav-item folder';
        header.title = labelText;
        
        let folderIcon = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>';
        if (isFavFolder) {
            folderIcon = '<svg width="16" height="16" viewBox="0 0 24 24" fill="#FFD700" stroke="#FFD700" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>';
        }

        header.innerHTML = `
            <div class="left-col">
              <svg class="chevron-folder" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="9 18 15 12 9 6"></polyline></svg>
              <div class="icon-box">
                 ${folderIcon}
              </div>
              <span class="label">${labelText}</span>
            </div>`;
            
        const subMenu = document.createElement('div');
        subMenu.className = 'sub-menu';
        if (hasChildren && item.items.length > 0) {
            item.items.forEach(child => subMenu.appendChild(buildNode(child, false)));
        }
        
        if (subMenu.querySelector('.active-selection')) {
            itemDiv.classList.add('expanded');
            header.classList.add('active');
            header.querySelector('.chevron-folder').innerHTML = '<polyline points="6 9 12 15 18 9"></polyline>';
        }
        
        itemDiv.appendChild(header);
        itemDiv.appendChild(subMenu);
        return itemDiv;
    } else {
        // --- LINK RENDERING ---
        let iconSvg = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>';
        
        // APPLY DEV ICON (Warning Triangle)
        if (isDev) {
             iconSvg = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#cf6679" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>';
        } else if (labelText === "Home") {
            iconSvg = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>';
        } else if (item.linkType === 'excel') {
             iconSvg = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#4caf50" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>';
        }

        const isFav = favoritesList.includes(item.url);
        const starClass = isFav ? 'fav-active' : '';
        const starFill = isFav ? '#FFD700' : 'none';
        const starStroke = isFav ? '#FFD700' : 'currentColor';

        itemDiv.className = `nav-item report ${activeClass}`;
        itemDiv.setAttribute('data-url', item.url);
        itemDiv.setAttribute('data-search-label', labelText.toLowerCase());
        
        // We stick "data-dev" here just for styling reference, but no logic relies on it anymore.
        if(isDev) itemDiv.setAttribute('data-dev', 'true');
        
        itemDiv.title = labelText;
        
        itemDiv.innerHTML = `
          <div class="left-col">
              <div class="icon-box report-icon">
                ${iconSvg}
              </div>
              <span class="label">${labelText}</span>
          </div>
          <div class="fav-action ${starClass}" title="${isFav ? 'Remove Favorite' : 'Add to Favorites'}">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="${starFill}" stroke="${starStroke}" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
          </div>
        `;
        
        const favBtn = itemDiv.querySelector('.fav-action');
        favBtn.addEventListener('click', (e) => {
            e.stopPropagation(); 
            e.preventDefault();
            toggleFavorite(item.url);
        });

        return itemDiv;
    }
  }
  
  menuData.forEach(rootItem => container.appendChild(buildNode(rootItem, true)));
}

// ==========================================
// 4. MASTER INTERACTION LOGIC (EVENT DELEGATION)
// ==========================================
document.getElementById('nav-tree-container').addEventListener('click', (e) => {
    // 1. Handle FOLDER clicks
    const folder = e.target.closest('.nav-item.folder');
    if (folder) {
        e.preventDefault();
        e.stopPropagation();
        const parentGroup = folder.closest('.nav-group');
        if (parentGroup.classList.contains('expanded')) {
            parentGroup.classList.remove('expanded');
            const chevron = folder.querySelector('.chevron-folder');
            if(chevron) chevron.innerHTML = '<polyline points="9 18 15 12 9 6"></polyline>';
        } else {
            parentGroup.classList.add('expanded');
            const chevron = folder.querySelector('.chevron-folder');
            if(chevron) chevron.innerHTML = '<polyline points="6 9 12 15 18 9"></polyline>';
        }
        return;
    }

    // 2. Handle REPORT clicks
    const reportItem = e.target.closest('.nav-item.report');
    if (reportItem) {
        // If they clicked the Star, ignore (handled above)
        if (e.target.closest('.fav-action')) return;
        
        e.preventDefault();
        e.stopPropagation();

        let url = reportItem.getAttribute('data-url');

        if (url && url !== "undefined" && url !== "#") {
            // Clean URL
            if (!url.startsWith('http') && !url.startsWith('//') && !url.startsWith('chrome-extension')) {
                url = chrome.runtime.getURL(url);
            }

            // JUST NAVIGATE (Logic for dev warning is in content.js now)
            localStorage.setItem('sidebar-floating', 'false');
            localStorage.setItem('sidebar-mini', 'true');
            window.parent.location.href = url;
        }
    }
});

// Search Logic
const searchInput = document.querySelector('.search-box input');
if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      const term = e.target.value.toLowerCase().trim();
      const allGroups = document.querySelectorAll('.nav-group');
      const allReports = document.querySelectorAll('.nav-item.report');
      if (term === '') {
        allGroups.forEach(g => {
            g.style.display = 'block';
            if (!g.querySelector('.active-selection')) {
                g.classList.remove('expanded'); 
            }
        });
        allReports.forEach(r => r.style.display = 'flex');
        return;
      }
      allGroups.forEach(g => g.style.display = 'none');
      allReports.forEach(r => r.style.display = 'none');
      const matches = [];
      allReports.forEach(r => { if (r.getAttribute('data-search-label').includes(term)) matches.push(r); });
      allGroups.forEach(g => { if (g.getAttribute('data-search-label').includes(term)) matches.push(g); });
      matches.forEach(match => {
          match.style.display = (match.classList.contains('nav-group')) ? 'block' : 'flex';
          if (match.classList.contains('nav-group')) {
             match.classList.add('expanded');
             const children = match.querySelectorAll(':scope > .sub-menu > .nav-item, :scope > .sub-menu > .nav-group');
             children.forEach(c => c.style.display = (c.classList.contains('nav-group')) ? 'block' : 'flex');
          }
          let parent = match.parentElement.closest('.nav-group');
          while (parent) {
              parent.style.display = 'block';
              parent.classList.add('expanded');
              parent = parent.parentElement.closest('.nav-group');
          }
      });
    });
}