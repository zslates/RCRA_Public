// ==================================================
// RCRA BI PORTAL - BACKGROUND SERVICE WORKER
// ==================================================

// 1. Handle the "Toggle" click (User clicks Star Icon)
chrome.action.onClicked.addListener(async (tab) => {
  // Get current state (default to false if undefined)
  const data = await chrome.storage.local.get('isSidebarOpen');
  const newState = !data.isSidebarOpen;

  // Save the new state
  await chrome.storage.local.set({ isSidebarOpen: newState });

  if (newState) {
    // === SMART TOGGLE STRATEGY ===
    try {
      // 1. Try to wake up the existing script first
      // This prevents the "Double Injection" crash
      await chrome.tabs.sendMessage(tab.id, { action: 'OPEN_SIDEBAR' });
    } catch (err) {
      // 2. If message fails (script doesn't exist yet), INJECT it
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      }).catch(() => {});
    }
  } else {
    // Turn Off
    try {
      await chrome.tabs.sendMessage(tab.id, { action: 'REMOVE_SIDEBAR' });
    } catch (err) {
      // Ignore if not there
    }
  }
});

// 2. Handle Navigation (User goes to new page)
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  // Inject immediately on load to prevent "pop-in" delay
  if (changeInfo.status === 'loading') {
    const data = await chrome.storage.local.get('isSidebarOpen');
    if (data.isSidebarOpen) {
      // Don't inject into restricted chrome:// or edge:// pages
      if (tab.url && !tab.url.startsWith('chrome://') && !tab.url.startsWith('edge://')) {
        chrome.scripting.executeScript({
          target: { tabId: tabId },
          files: ['content.js']
        }).catch(() => {});
      }
    }
  }
});