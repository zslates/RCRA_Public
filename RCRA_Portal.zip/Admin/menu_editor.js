// Global State
let rootData = [];
let selectedPath = null;
let currentSha = null;
let dragSrcPath = null; 

// --- INIT ---
document.addEventListener('DOMContentLoaded', () => {
    console.log("Admin Editor Loaded");

    const owner = localStorage.getItem('gh_owner');
    const repo = localStorage.getItem('gh_repo');
    const path = localStorage.getItem('gh_path');
    const token = localStorage.getItem('gh_token');

    if(owner) document.getElementById('gh-owner').value = owner;
    if(repo) document.getElementById('gh-repo').value = repo;
    if(path) document.getElementById('gh-path').value = path;
    if(token) document.getElementById('gh-token').value = token;

    // Attach Listeners
    document.getElementById('btn-save-creds').addEventListener('click', saveCreds);
    document.getElementById('btn-load').addEventListener('click', loadFromCloud);
    document.getElementById('btn-publish').addEventListener('click', publishToCloud);
    document.getElementById('btn-add-root').addEventListener('click', () => addItem(true));
    document.getElementById('btn-update').addEventListener('click', updateItem);
    document.getElementById('btn-delete').addEventListener('click', deleteItem);
    document.getElementById('inp-type').addEventListener('change', toggleUI);
    document.getElementById('btn-add-sub-folder').addEventListener('click', () => addItem(false, 'folder'));
    document.getElementById('btn-add-sub-link').addEventListener('click', () => addItem(false, 'report'));
    document.getElementById('btn-up').addEventListener('click', () => moveItem(-1));
    document.getElementById('btn-down').addEventListener('click', () => moveItem(1));

    if (token && owner && repo) {
        console.log("Auto-loading...");
        loadFromCloud();
    } else {
        toast("System Ready - Please set Credentials");
    }
});

// --- ACTIONS ---
function saveCreds() {
    localStorage.setItem('gh_owner', document.getElementById('gh-owner').value);
    localStorage.setItem('gh_repo', document.getElementById('gh-repo').value);
    localStorage.setItem('gh_path', document.getElementById('gh-path').value);
    localStorage.setItem('gh_token', document.getElementById('gh-token').value);
    document.getElementById('details-settings').removeAttribute('open');
    toast("Settings Saved");
    if (rootData.length === 0) loadFromCloud();
}

async function loadFromCloud() {
    const token = document.getElementById('gh-token').value.trim();
    const owner = document.getElementById('gh-owner').value.trim();
    const repo = document.getElementById('gh-repo').value.trim();
    const path = document.getElementById('gh-path').value.trim();

    if(!token || !owner) return toast("⚠️ Check Settings");

    toast("⏳ Loading...");
    const url = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;

    try {
        const res = await fetch(url + '?t=' + new Date().getTime(), { 
            headers: { Authorization: `token ${token}` } 
        });
        
        if(!res.ok) throw new Error(res.status);
        
        const data = await res.json();
        currentSha = data.sha;
        const json = decodeURIComponent(escape(window.atob(data.content)));
        rootData = JSON.parse(json);
        
        renderTree();
        toast("✅ Loaded");
    } catch(e) {
        alert("Load Error: " + e.message);
    }
}

async function publishToCloud() {
    if(!currentSha) return alert("You must LOAD first to get the SHA.");
    if(!confirm("Publish changes live?")) return;

    const token = document.getElementById('gh-token').value.trim();
    const owner = document.getElementById('gh-owner').value.trim();
    const repo = document.getElementById('gh-repo').value.trim();
    const path = document.getElementById('gh-path').value.trim();

    toast("⏳ Publishing...");
    const url = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;
    const content = JSON.stringify(rootData, null, 2);
    const encoded = window.btoa(unescape(encodeURIComponent(content)));

    try {
        const res = await fetch(url, {
            method: 'PUT',
            headers: { Authorization: `token ${token}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: "Update via Admin Tool", content: encoded, sha: currentSha })
        });
        
        if(!res.ok) throw new Error(res.statusText);
        const data = await res.json();
        currentSha = data.content.sha;
        toast("🚀 Published!");
    } catch(e) {
        alert("Publish Error: " + e.message);
    }
}

// --- TREE UI (SMART DRAG) ---
function renderTree() {
    const container = document.getElementById('tree-root');
    container.innerHTML = '';

    function buildNode(item, path) {
        const wrapper = document.createElement('div');
        wrapper.className = 'expanded'; 

        const nodeDiv = document.createElement('div');
        const isSel = JSON.stringify(path) === JSON.stringify(selectedPath);
        const hasKids = item.items && Array.isArray(item.items);

        nodeDiv.className = 'node ' + (isSel ? 'selected' : '');
        nodeDiv.draggable = true;
        
        const label = item.category || item.name || 'Untitled';
        
        // 1. Expansion Toggle
        const arrowSpan = document.createElement('span');
        arrowSpan.className = 'toggle-icon';
        arrowSpan.style.pointerEvents = 'auto'; 
        arrowSpan.style.marginRight = '5px';
        arrowSpan.innerText = hasKids ? '▼' : '•';
        
        if (hasKids) {
            arrowSpan.onclick = (e) => {
                e.stopPropagation(); 
                wrapper.classList.toggle('expanded');
                arrowSpan.innerText = wrapper.classList.contains('expanded') ? '▼' : '▶';
            };
        }

        // Icon Selection for Editor
        let iconChar = '🔗';
        if (hasKids) iconChar = '📁';
        else if (item.linkType === 'excel') iconChar = '📗';

        const textSpan = document.createElement('span');
        textSpan.innerText = `${iconChar} ${label}`;
        
        nodeDiv.appendChild(arrowSpan);
        nodeDiv.appendChild(textSpan);
        
        // 2. Events
        nodeDiv.addEventListener('click', (e) => { 
            e.stopPropagation(); 
            select(path); 
        });

        // 3. Drag Logic
        nodeDiv.addEventListener('dragstart', (e) => {
            e.stopPropagation();
            dragSrcPath = path;
            e.dataTransfer.effectAllowed = 'move';
            setTimeout(() => nodeDiv.style.opacity = '0.5', 0);
        });

        nodeDiv.addEventListener('dragend', () => {
            nodeDiv.style.opacity = '1';
            clearDragClasses();
        });

        nodeDiv.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.stopPropagation();
            clearDragClasses();

            const rect = nodeDiv.getBoundingClientRect();
            const relY = e.clientY - rect.top;
            const height = rect.height;
            
            if (relY < height * 0.25) {
                nodeDiv.classList.add('drop-above');
            } else if (relY > height * 0.75) {
                nodeDiv.classList.add('drop-below');
            } else {
                if (hasKids) nodeDiv.classList.add('drop-inside');
                else nodeDiv.classList.add('drop-below'); 
            }
        });

        nodeDiv.addEventListener('drop', (e) => {
            e.stopPropagation();
            e.preventDefault();
            
            let action = 'inside';
            if (nodeDiv.classList.contains('drop-above')) action = 'above';
            else if (nodeDiv.classList.contains('drop-below')) action = 'below';
            
            clearDragClasses();
            handleDrop(path, action);
        });

        wrapper.appendChild(nodeDiv);

        if(hasKids && item.items.length > 0) {
            const kidsBox = document.createElement('div');
            kidsBox.className = 'children'; 
            item.items.forEach((k, i) => {
                kidsBox.appendChild(buildNode(k, [...path, i]));
            });
            wrapper.appendChild(kidsBox);
        }
        return wrapper;
    }

    rootData.forEach((item, i) => container.appendChild(buildNode(item, [i])));
}

function clearDragClasses() {
    document.querySelectorAll('.drop-above, .drop-below, .drop-inside').forEach(el => {
        el.className = el.className.replace(/\bdrop-\S+/g, '');
    });
}

function handleDrop(targetPath, action) {
    if (!dragSrcPath) return;
    if (JSON.stringify(dragSrcPath) === JSON.stringify(targetPath)) return;

    let srcParent = rootData;
    if (dragSrcPath.length > 1) {
        for(let i=0; i<dragSrcPath.length-1; i++) srcParent = srcParent[dragSrcPath[i]].items;
    }
    const srcIndex = dragSrcPath[dragSrcPath.length-1];
    const itemToMove = srcParent[srcIndex];

    // Unique ID Strategy to prevent index errors
    const uniqueId = Date.now() + Math.random();
    itemToMove._moveId = uniqueId;
    
    const clonedItem = JSON.parse(JSON.stringify(itemToMove));
    delete clonedItem._moveId; 

    let destNode = rootData[targetPath[0]];
    for(let i=1; i<targetPath.length; i++) destNode = destNode.items[targetPath[i]];

    if (action === 'inside') {
        if(!destNode.items) destNode.items = [];
        destNode.items.push(clonedItem);
    } else {
        let destParent = rootData;
        if (targetPath.length > 1) {
            for(let i=0; i<targetPath.length-1; i++) destParent = destParent[targetPath[i]].items;
        }
        const destIndex = targetPath[targetPath.length-1];
        const insertAt = action === 'above' ? destIndex : destIndex + 1;
        destParent.splice(insertAt, 0, clonedItem);
    }

    deleteById(rootData, uniqueId);
    delete itemToMove._moveId; 

    dragSrcPath = null;
    selectedPath = null;
    renderTree();
    toast("Moved!");
}

function deleteById(items, id) {
    for (let i = 0; i < items.length; i++) {
        if (items[i]._moveId === id) {
            items.splice(i, 1);
            return true;
        }
        if (items[i].items) {
            if (deleteById(items[i].items, id)) return true;
        }
    }
    return false;
}

// --- EDITOR FORM LOGIC ---
function select(path) {
    selectedPath = path;
    renderTree();
    
    let node = rootData[path[0]];
    for(let i=1; i<path.length; i++) node = node.items[path[i]];

    document.getElementById('editor-ui').style.display = 'block';
    document.getElementById('empty-msg').style.display = 'none';
    
    const isFolder = node.items !== undefined;
    document.getElementById('inp-type').value = isFolder ? 'folder' : 'report';
    document.getElementById('inp-name').value = node.category || node.name || "";
    document.getElementById('inp-url').value = node.url || "";
    
    // LOAD LINK TYPE
    const linkTypeEl = document.getElementById('inp-link-type');
    if (linkTypeEl) {
        linkTypeEl.value = node.linkType || 'report';
    }
    
    toggleUI();
}

function updateItem() {
    if(!selectedPath) return;
    const { parent, index } = getParentAndIndex(selectedPath);
    const node = parent[index];
    const name = document.getElementById('inp-name').value;
    const type = document.getElementById('inp-type').value;

    if(selectedPath.length === 1) { node.category = name; delete node.name; }
    else { node.name = name; delete node.category; }

    if(type === 'report') {
        node.url = document.getElementById('inp-url').value;
        // SAVE LINK TYPE
        const linkTypeEl = document.getElementById('inp-link-type');
        if (linkTypeEl) {
            node.linkType = linkTypeEl.value;
        }
        delete node.items;
    } else {
        delete node.url;
        delete node.linkType; // Folders don't have types
        if(!node.items) node.items = [];
    }
    renderTree();
    toast("Updated");
}

function addItem(isRoot, type) {
    if(isRoot) {
        rootData.push({ category: "New Root", items: [] });
        select([rootData.length-1]);
    } else {
        let node = rootData[selectedPath[0]];
        for(let i=1; i<selectedPath.length; i++) node = node.items[selectedPath[i]];
        
        if(!node.items) node.items = [];
        
        // Add default linkType for new links
        const newItem = type === 'folder' 
            ? { name: "New Folder", items: [] } 
            : { name: "New Link", url: "", linkType: "report" };
            
        node.items.push(newItem);
        renderTree();
    }
}

function deleteItem() {
    if(!confirm("Delete?")) return;
    const { parent, index } = getParentAndIndex(selectedPath);
    parent.splice(index, 1);
    selectedPath = null;
    document.getElementById('editor-ui').style.display = 'none';
    renderTree();
}

function moveItem(dir) {
    if(!selectedPath) return;
    const { parent, index } = getParentAndIndex(selectedPath);
    const newIdx = index + dir;
    if(newIdx >= 0 && newIdx < parent.length) {
        [parent[index], parent[newIdx]] = [parent[newIdx], parent[index]];
        selectedPath[selectedPath.length-1] = newIdx;
        renderTree();
    }
}

function getParentAndIndex(path) {
    let parent = rootData;
    if(path.length > 1) {
        for(let i=0; i<path.length-1; i++) parent = parent[path[i]].items;
    }
    return { parent, index: path[path.length-1] };
}

function toggleUI() {
    const isFolder = document.getElementById('inp-type').value === 'folder';
    document.getElementById('box-url').style.display = isFolder ? 'none' : 'block';
    document.getElementById('box-children').style.display = isFolder ? 'block' : 'none';
}

function toast(msg) {
    const t = document.getElementById('toast');
    t.innerText = msg;
    t.style.display = 'block';
    setTimeout(() => t.style.display = 'none', 3000);
}