// ==================================================
// RCRA BI PORTAL - CONTENT SCRIPT
// Handles the Iframe injection and Website resizing
// ==================================================

// FIX: Use 'var' instead of 'let' so it doesn't crash if injected twice
var pendingLayout = { width: '0px', height: '100vh', push: '0px', side: 'right', isFloating: false };

function initSidebar() {
  // Prevent double iframe creation
  if (document.getElementById('rcra-sidebar-frame')) return;

  const iframe = document.createElement('iframe');
  iframe.id = 'rcra-sidebar-frame';
  iframe.src = chrome.runtime.getURL('sidebar.html') + '?parent=' + encodeURIComponent(window.location.href);
  
  // FIX: Transparent background so no white box appears in floating mode
  iframe.style.cssText = `
    position: fixed;
    top: 0;
    height: 100vh;
    border: none;
    z-index: 2147483647;
    background: transparent !important; 
    color-scheme: normal;
    transition: width 0.3s ease; 
  `;

  // HANDSHAKE: Ask sidebar for layout immediately
  iframe.onload = () => {
    iframe.contentWindow.postMessage({ action: 'REQUEST_LAYOUT' }, '*');
  };

  const target = document.documentElement;
  target.appendChild(iframe);
}

// Helper to safely apply margins and dimensions
function applyLayout(data) {
    const width = data.width || '300px';
    const height = data.height || '100vh';
    const push = data.push || width;
    const side = data.side || 'right';
    const isFloating = data.isFloating || false;

    // Update memory
    pendingLayout = { width, height, push, side, isFloating };
    
    // 1. Resize/Move the Iframe
    const frame = document.getElementById('rcra-sidebar-frame');
    if (frame) {
        frame.style.width = width;
        frame.style.height = height;

        // FIX: Remove shadow if floating (bubble has its own shadow)
        if (isFloating) {
            frame.style.boxShadow = 'none';
        } else {
            frame.style.boxShadow = '0 0 10px rgba(0,0,0,0.2)';
        }

        if (side === 'left') {
            frame.style.left = '0';
            frame.style.right = 'auto';
            frame.style.borderRight = '1px solid rgba(0,0,0,0.1)';
            frame.style.borderLeft = 'none';
        } else {
            frame.style.right = '0';
            frame.style.left = 'auto';
            frame.style.borderLeft = '1px solid rgba(0,0,0,0.1)';
            frame.style.borderRight = 'none';
        }
    }

    // 2. Squish the Website (THE FIX: Target HTML only)
    const htmlNode = document.documentElement;
    
    if (htmlNode) {
        htmlNode.style.transition = 'margin-left 0.3s ease, margin-right 0.3s ease';
        
        if (side === 'left') {
            htmlNode.style.setProperty('margin-left', push, 'important');
            htmlNode.style.setProperty('margin-right', '0px', 'important');
        } else {
            htmlNode.style.setProperty('margin-right', push, 'important');
            htmlNode.style.setProperty('margin-left', '0px', 'important');
        }
    }
}

// ==================================================
// INITIALIZATION
// ==================================================

// Auto-run if page is ready
if (document.documentElement) {
  initSidebar();
}

// Re-apply layout on full load (Double Tap safety)
window.addEventListener('load', () => {
    if (pendingLayout.width !== '0px') {
        applyLayout(pendingLayout);
    }
});

// ==================================================
// MESSAGE LISTENERS
// ==================================================
if (!window.rcraListenersActive) {
  window.rcraListenersActive = true;

  // 1. Listen for Iframe Messages (Layout Updates)
  window.addEventListener('message', (event) => {
    if (event.data.action === 'UPDATE_LAYOUT') {
       applyLayout(event.data);
    }
  });

  // 2. Listen for Background Commands
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'REMOVE_SIDEBAR') {
      const frame = document.getElementById('rcra-sidebar-frame');
      if (frame) frame.remove();
      
      // Reset Website Margins (Target HTML only)
      if (document.documentElement) {
          document.documentElement.style.marginLeft = '0px';
          document.documentElement.style.marginRight = '0px';
      }
      
      // Reset Memory
      pendingLayout = { width: '0px', height: '100vh', push: '0px', side: 'right', isFloating: false };
    }
    
    // NEW: Wake up command (Fixes the "won't turn back on" bug)
    if (request.action === 'OPEN_SIDEBAR') {
        initSidebar();
    }
  });
}