// ==========================================
// 1. CONFIGURATION
// ==========================================
const MENU_URL = 'https://raw.githubusercontent.com/zslates/RCRA_Public/main/menu2.json';

// ==========================================
// 2. INITIALIZATION & LOGIC
// ==========================================

document.addEventListener('DOMContentLoaded', () => {
  initSidebar();
  initMenu();
});

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') {
    initMenu();
  }
});

function initSidebar() {
  const body = document.body;
  const toggleBtn = document.getElementById('sidebar-toggle');
  const hideBtn = document.getElementById('hide-sidebar-btn');
  const floatIcon = document.getElementById('floating-icon');
  
  const btnLeft = document.getElementById('btn-left');
  const btnRight = document.getElementById('btn-right');

  // --- UPDATED LAYOUT LOGIC ---
  const updateParentLayout = () => {
    const isFloating = body.classList.contains('floating-mode');
    const isMini = body.classList.contains('mini-mode');
    const side = localStorage.getItem('sidebar-side') || 'right';
    
    let frameWidth, frameHeight, pagePush;

    if (isFloating) {
        // FLOATING MODE: Tighten to 60px
        frameWidth = '60px';   
        frameHeight = '60px';  
        pagePush = '0px';      
    } else {
        // NORMAL MODES
        frameWidth = isMini ? '65px' : '300px';
        frameHeight = '100vh'; 
        pagePush = frameWidth; 
    }

    window.parent.postMessage({ 
      action: 'UPDATE_LAYOUT', 
      width: frameWidth,
      height: frameHeight,
      push: pagePush,
      side: side,
      isFloating: isFloating // Tell content.js to remove shadow
    }, '*');
  };

  // --- EVENT LISTENERS ---

  if (toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      body.classList.toggle('mini-mode');
      localStorage.setItem('sidebar-mini', body.classList.contains('mini-mode'));
      updateParentLayout();
    });
  }

  // Hide Button (Up Arrow) -> Enters Floating Mode
  if (hideBtn) {
      hideBtn.addEventListener('click', () => {
          body.classList.add('floating-mode');
          localStorage.setItem('sidebar-floating', 'true');
          updateParentLayout();
      });
  }

  // Floating Icon Click -> Exits Floating Mode -> GOES TO FULL MENU
  if (floatIcon) {
      floatIcon.addEventListener('click', () => {
          body.classList.remove('floating-mode');
          localStorage.setItem('sidebar-floating', 'false');
          
          // Force Full Mode (Remove mini-mode class)
          body.classList.remove('mini-mode');
          localStorage.setItem('sidebar-mini', 'false'); 
          
          updateParentLayout();
      });
  }

  // --- SIDE SWITCHING ---
  const setSide = (side) => {
    localStorage.setItem('sidebar-side', side);
    if (btnLeft && btnRight) {
        if (side === 'left') {
          btnLeft.style.background = '#6a4c93'; btnLeft.style.color = 'white';
          btnRight.style.background = 'rgba(0,0,0,0.2)'; btnRight.style.color = '#aea0c0';
        } else {
          btnRight.style.background = '#6a4c93'; btnRight.style.color = 'white';
          btnLeft.style.background = 'rgba(0,0,0,0.2)'; btnLeft.style.color = '#aea0c0';
        }
    }
    updateParentLayout();
  };

  if (btnLeft && btnRight) {
    btnLeft.addEventListener('click', () => setSide('left'));
    btnRight.addEventListener('click', () => setSide('right'));
  }

  // --- LOAD SAVED STATES ---
  if (localStorage.getItem('sidebar-floating') === 'true') {
      body.classList.add('floating-mode');
  } else if (localStorage.getItem('sidebar-mini') === 'true') {
      body.classList.add('mini-mode');
  }
  
  const savedSide = localStorage.getItem('sidebar-side') || 'right';
  setSide(savedSide);

  // --- HANDSHAKE LISTENER ---
  window.addEventListener('message', (event) => {
    if (event.data.action === 'REQUEST_LAYOUT') {
      updateParentLayout();
    }
  });
}

// ==========================================
// INIT MENU: Stale-While-Revalidate Strategy
// ==========================================
async function initMenu() {
  const container = document.getElementById('nav-tree-container');
  
  const isCompact = document.body.classList.contains('mini-mode') || document.body.classList.contains('floating-mode');
  
  // STEP 1: LOAD FROM CACHE (Speed)
  let currentData = [];
  try {
    const stored = await chrome.storage.local.get('cachedMenu');
    if (stored.cachedMenu) {
      currentData = stored.cachedMenu;
      renderMenu(currentData, container);
    } else if (!isCompact) {
      // Only show loading if we aren't minified and have no cache
      container.innerHTML = '<div style="padding:20px; color:#aaa;">Loading...</div>';
    }
  } catch (e) { 
      console.warn("Error reading local storage:", e); 
  }

  // STEP 2: FETCH LIVE UPDATES (Truth)
  try {
    const response = await fetch(MENU_URL + '?t=' + new Date().getTime());
    if (!response.ok) throw new Error(`GitHub Error: ${response.status}`);
    const liveData = await response.json();
    
    // Only update if data actually changed
    if (JSON.stringify(liveData) !== JSON.stringify(currentData)) {
      console.log("🚀 Update found! Refreshing UI...");
      await chrome.storage.local.set({ cachedMenu: liveData });
      renderMenu(liveData, container);
    }
  } catch (error) {
    console.error('Background fetch failed (using cache):', error);
    if (currentData.length === 0 && !isCompact) {
       container.innerHTML = '<div style="padding:20px; color:#ff6b6b;">Failed to load menu.</div>';
    }
  }
}

// ==========================================
// 3. RENDER LOGIC
// ==========================================
function renderMenu(menuData, container) {
  container.innerHTML = '';
  const urlParams = new URLSearchParams(window.location.search);
  const rawParentUrl = urlParams.get('parent') || '';
  const currentUrl = rawParentUrl.toLowerCase().replace(/\/$/, "");

  function buildNode(item, isRoot) {
    const labelText = isRoot ? (item.category || item.name) : item.name;
    const hasChildren = item.items && Array.isArray(item.items);
    const isFolder = (item.items !== undefined); 

    const itemDiv = document.createElement('div');
    let isActive = false;
    if (item.url) {
        let itemUrlFull = item.url;
        if (!itemUrlFull.startsWith('http') && !itemUrlFull.startsWith('//') && !itemUrlFull.startsWith('chrome')) {
             itemUrlFull = chrome.runtime.getURL(itemUrlFull);
        }
        const cleanItemUrl = itemUrlFull.toLowerCase().replace(/\/$/, "");
        if (cleanItemUrl.length > 5 && currentUrl.includes(cleanItemUrl)) {
            isActive = true;
        }
    }
    const activeClass = isActive ? 'active-selection' : '';

    if (isFolder) {
        itemDiv.className = 'nav-group';
        itemDiv.setAttribute('data-search-label', labelText.toLowerCase());
        const header = document.createElement('div');
        header.className = 'nav-item folder';
        header.title = labelText;
        header.innerHTML = `
            <div class="left-col">
              <svg class="chevron-folder" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="9 18 15 12 9 6"></polyline></svg>
              <div class="icon-box">
                 <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
              </div>
              <span class="label">${labelText}</span>
            </div>`;
        const subMenu = document.createElement('div');
        subMenu.className = 'sub-menu';
        if (hasChildren && item.items.length > 0) {
            item.items.forEach(child => subMenu.appendChild(buildNode(child, false)));
        }
        if (subMenu.querySelector('.active-selection')) {
            itemDiv.classList.add('expanded');
            header.classList.add('active');
            header.querySelector('.chevron-folder').innerHTML = '<polyline points="6 9 12 15 18 9"></polyline>';
        }
        itemDiv.appendChild(header);
        itemDiv.appendChild(subMenu);
        return itemDiv;
    } else {
        itemDiv.className = `nav-item report ${activeClass}`;
        itemDiv.setAttribute('data-url', item.url);
        itemDiv.setAttribute('data-search-label', labelText.toLowerCase());
        itemDiv.title = labelText;
        itemDiv.innerHTML = `
          <div class="icon-box report-icon">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
          </div>
          <span class="label">${labelText}</span>`;
        return itemDiv;
    }
  }
  menuData.forEach(rootItem => container.appendChild(buildNode(rootItem, true)));
  setupInteractions();
}

// ==========================================
// 4. INTERACTION & SEARCH LOGIC
// ==========================================
function setupInteractions() {
  const reportItems = document.querySelectorAll('.nav-item.report');
  reportItems.forEach(item => {
    item.addEventListener('click', async (e) => {
      e.stopPropagation(); 
      let url = item.getAttribute('data-url');
      if (url && url !== "undefined" && url !== "#") {
        if (!url.startsWith('http') && !url.startsWith('//') && !url.startsWith('chrome-extension')) {
          url = chrome.runtime.getURL(url);
        }
        
        // Reset modes on click
        localStorage.setItem('sidebar-floating', 'false');
        localStorage.setItem('sidebar-mini', 'true');
        
        window.parent.location.href = url;
      }
    });
  });

  const searchInput = document.querySelector('.search-box input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      const term = e.target.value.toLowerCase().trim();
      const allGroups = document.querySelectorAll('.nav-group');
      const allReports = document.querySelectorAll('.nav-item.report');
      if (term === '') {
        allGroups.forEach(g => {
            g.style.display = 'block';
            if (!g.querySelector('.active-selection')) collapseGroup(g); 
        });
        allReports.forEach(r => r.style.display = 'flex');
        return;
      }
      allGroups.forEach(g => g.style.display = 'none');
      allReports.forEach(r => r.style.display = 'none');
      const matches = [];
      allReports.forEach(r => { if (r.getAttribute('data-search-label').includes(term)) matches.push(r); });
      allGroups.forEach(g => { if (g.getAttribute('data-search-label').includes(term)) matches.push(g); });
      matches.forEach(match => {
          match.style.display = (match.classList.contains('nav-group')) ? 'block' : 'flex';
          if (match.classList.contains('nav-group')) {
             expandGroup(match);
             const children = match.querySelectorAll(':scope > .sub-menu > .nav-item, :scope > .sub-menu > .nav-group');
             children.forEach(c => c.style.display = (c.classList.contains('nav-group')) ? 'block' : 'flex');
          }
          let parent = match.parentElement.closest('.nav-group');
          while (parent) {
              parent.style.display = 'block';
              expandGroup(parent);
              parent = parent.parentElement.closest('.nav-group');
          }
      });
    });
  }

  const folders = document.querySelectorAll('.nav-item.folder');
  folders.forEach(folder => {
    folder.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation(); 
      const parentGroup = this.closest('.nav-group');
      if (parentGroup.classList.contains('expanded')) collapseGroup(parentGroup);
      else expandGroup(parentGroup);
    });
  });
}

function expandGroup(group) {
  group.classList.add('expanded');
  const folder = group.querySelector(':scope > .folder'); 
  if(folder) {
      folder.classList.add('active');
      folder.querySelector('.chevron-folder').innerHTML = '<polyline points="6 9 12 15 18 9"></polyline>'; 
  }
}

function collapseGroup(group) {
  group.classList.remove('expanded');
  const folder = group.querySelector(':scope > .folder');
  if(folder) {
      folder.classList.remove('active');
      folder.querySelector('.chevron-folder').innerHTML = '<polyline points="9 18 15 12 9 6"></polyline>';
  }
}