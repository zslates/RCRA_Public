// interceptor.js
(function() {
    console.log("RCRA: Token Interceptor Injected into MAIN world!");
    
    // Hijack Fetch API
    const originalFetch = window.fetch;
    window.fetch = async function(...args) {
        try {
            const [resource, config] = args;
            if (config && config.headers) {
                let authHeader = null;
                if (config.headers instanceof Headers) {
                    authHeader = config.headers.get('Authorization');
                } else if (typeof config.headers === 'object') {
                    const authKey = Object.keys(config.headers).find(k => k.toLowerCase() === 'authorization');
                    if (authKey) authHeader = config.headers[authKey];
                }
                
                if (authHeader && authHeader.startsWith('Bearer ')) {
                    window.postMessage({ action: 'RCRA_INTERCEPTED_TOKEN', token: authHeader.replace('Bearer ', '') }, '*');
                }
            }
        } catch(e) {} 
        return originalFetch.apply(this, args);
    };
    
    // Hijack XMLHttpRequest
    const originalSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
    XMLHttpRequest.prototype.setRequestHeader = function(header, value) {
        try {
            if (header.toLowerCase() === 'authorization' && value.startsWith('Bearer ')) {
                window.postMessage({ action: 'RCRA_INTERCEPTED_TOKEN', token: value.replace('Bearer ', '') }, '*');
            }
        } catch(e) {}
        return originalSetRequestHeader.apply(this, arguments);
    };
})();