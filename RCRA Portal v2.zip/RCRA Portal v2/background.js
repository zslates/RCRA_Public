// ==================================================
// RCRA BI PORTAL - BACKGROUND SERVICE WORKER
// ==================================================

// Config: Needs to match sidebar.js
const MENU_URL = 'https://raw.githubusercontent.com/zslates/RCRA_Public/main/menu2.json';
const DEFAULT_HOME = "https://app.powerbi.com/home";

// ==========================================
// 1. HELPER: DYNAMIC HOME URL
// ==========================================
async function getDynamicHomeUrl() {
  try {
    const stored = await chrome.storage.local.get('cachedMenu');
    let data = stored.cachedMenu;

    if (!data || data.length === 0) {
       const res = await fetch(MENU_URL);
       data = await res.json();
       await chrome.storage.local.set({ cachedMenu: data });
    }

    let menuArray = Array.isArray(data) ? data : (data.menu || []);

    const findFirstLink = (items) => {
        for (const item of items) {
            if (item.url && item.url !== "#") return item.url;
            if (item.items && item.items.length > 0) {
                const found = findFirstLink(item.items);
                if (found) return found;
            }
        }
        return null;
    };

    const firstUrl = findFirstLink(menuArray);
    
    if (firstUrl) {
         if (!firstUrl.startsWith('http') && !firstUrl.startsWith('//')) {
             return DEFAULT_HOME; 
         }
         return firstUrl;
    }

  } catch (e) {
    console.warn("Failed to determine dynamic home, using default.", e);
  }
  return DEFAULT_HOME;
}

// ==========================================
// 2. FABRIC API: MY WORKSPACE SYNC
// ==========================================

async function getFabricToken() {
    const data = await chrome.storage.local.get('fabricToken');
    return data.fabricToken || null;
}

async function syncFabricWorkspace() {
    console.log("RCRA Sync: Starting sync sequence...");
    try {
        const token = await getFabricToken();
        if (!token) {
            console.log("RCRA Sync: No intercepted token available yet. Waiting for user to interact with Power BI.");
            return;
        }

        const headers = { 'Authorization': `Bearer ${token}` };

        // 1. Get Personal Workspace ID
        console.log("RCRA Sync: Calling Fabric API to get workspaces...");
        const wsRes = await fetch('https://api.fabric.microsoft.com/v1/workspaces', { headers });
        
        if (!wsRes.ok) {
            console.error(`RCRA Sync: Fabric API rejected the token. Status: ${wsRes.status} ${wsRes.statusText}`);
            throw new Error(`Fabric API returned ${wsRes.status}. This usually means the intercepted token is scoped to Power BI, not Fabric.`);
        }
        
        const wsData = await wsRes.json();
        const personalWs = wsData.value.find(ws => ws.type === 'Personal');
        
        if (!personalWs) {
            console.log("RCRA Sync: Connected to Fabric API, but no 'Personal' workspace was found in the returned array.");
            return;
        }
        
        const wsId = personalWs.id;
        console.log(`RCRA Sync: Found Personal Workspace ID: ${wsId}`);

        // 2. Get Folders & Reports
        console.log("RCRA Sync: Fetching folders and reports...");
        const [foldersRes, reportsRes] = await Promise.all([
            fetch(`https://api.fabric.microsoft.com/v1/workspaces/${wsId}/folders`, { headers }),
            fetch(`https://api.fabric.microsoft.com/v1/workspaces/${wsId}/items?type=Report`, { headers })
        ]);

        const foldersData = foldersRes.ok ? await foldersRes.json() : { value: [] };
        const reportsData = reportsRes.ok ? await reportsRes.json() : { value: [] };
        console.log(`RCRA Sync: Retrieved ${foldersData.value.length} folders and ${reportsData.value.length} reports.`);

        // 3. Build the Hierarchy Tree
        const folderMap = {};
        const rootNodes = [];

        // Pass A: Initialize folders
        (foldersData.value || []).forEach(f => {
            folderMap[f.id] = { 
                name: f.displayName, 
                category: f.displayName, 
                items: [], 
                id: f.id, 
                parentId: f.parentFolderId,
                _isWorkspaceFolder: true,
                _expanded: false 
            };
        });

        // Pass B: Attach reports
        (reportsData.value || []).forEach(r => {
            const reportItem = { 
                name: r.displayName, 
                url: `https://app.powerbi.com/groups/me/reports/${r.id}`, 
                linkType: 'report', 
                _isWorkspaceItem: true 
            };
            if (r.folderId && folderMap[r.folderId]) {
                folderMap[r.folderId].items.push(reportItem);
            } else {
                rootNodes.push(reportItem);
            }
        });

        // Pass C: Attach subfolders to parents
        Object.values(folderMap).forEach(f => {
            const parentId = f.parentId;
            delete f.id;
            delete f.parentId;

            if (parentId && folderMap[parentId]) {
                folderMap[parentId].items.push(f);
            } else {
                rootNodes.push(f);
            }
        });

        // 4. Recursive Alphabetical Sort
        function sortTree(nodes) {
            nodes.sort((a, b) => {
                const nameA = (a.name || a.category || "").toLowerCase();
                const nameB = (b.name || b.category || "").toLowerCase();
                return nameA.localeCompare(nameB);
            });
            nodes.forEach(n => {
                if (n.items) sortTree(n.items);
            });
        }
        
        sortTree(rootNodes);

        // 5. Save to Local Storage 
        await chrome.storage.local.set({ rcraMyWorkspace: rootNodes });
        console.log("RCRA Sync: Workspace tree successfully compiled and saved to local storage!");

    } catch (error) {
        console.error("RCRA Sync Fatal Error:", error);
    }
}

// ----------------------------------------------------
// Option 4: Background Polling dropped to 1 Minute
// ----------------------------------------------------
chrome.alarms.create("syncFabricData", { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "syncFabricData") {
        syncFabricWorkspace();
    }
});


// ==========================================
// 3. LISTENER: MESSAGE BUS (Tokens & Identity)
// ==========================================
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // Catch the intercepted token from content.js
    if (request.action === 'SAVE_FABRIC_TOKEN' && request.token) {
        chrome.storage.local.get('fabricToken', (data) => {
            // Only update and re-sync if the token has actually changed
            if (data.fabricToken !== request.token) {
                chrome.storage.local.set({ fabricToken: request.token }, () => {
                    console.log("RCRA Sync: Fresh token saved. Triggering sync API sequence.");
                    syncFabricWorkspace(); 
                });
            }
        });
    }

    // Dev Bar Test Hook
    if (request.action === 'GET_USER_IDENTITY') {
        chrome.identity.getProfileUserInfo((userInfo) => {
            sendResponse({ email: userInfo.email || "" });
        });
        return true; 
    }
});

// ==========================================
// 4. LISTENER: ON INSTALL
// ==========================================
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === "install") {
    const targetUrl = await getDynamicHomeUrl();
    chrome.tabs.create({ url: targetUrl });
    chrome.storage.local.set({ isSidebarOpen: true });
    syncFabricWorkspace(); 
  }
});

// ==========================================
// 5. LISTENER: TOGGLE CLICK
// ==========================================
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.url.includes("app.powerbi.com")) return;

  const data = await chrome.storage.local.get('isSidebarOpen');
  const newState = !data.isSidebarOpen;
  await chrome.storage.local.set({ isSidebarOpen: newState });

  if (newState) {
    // ----------------------------------------------------
    // Option 3a: Force sync API pull when sidebar opens
    // ----------------------------------------------------
    syncFabricWorkspace();

    const homeUrl = await getDynamicHomeUrl();
    const currentClean = tab.url.toLowerCase().replace(/\/$/, "");
    const homeClean = homeUrl.toLowerCase().replace(/\/$/, "");
    
    if (!currentClean.includes(homeClean)) {
        await chrome.tabs.update(tab.id, { url: homeUrl });
    } else {
        try {
            await chrome.tabs.sendMessage(tab.id, { action: 'OPEN_SIDEBAR' });
        } catch (err) {
            injectSidebar(tab.id);
        }
    }
  } else {
    try {
      await chrome.tabs.sendMessage(tab.id, { action: 'REMOVE_SIDEBAR' });
    } catch (err) { }
  }
});

// ==========================================
// 6. LISTENER: PAGE NAVIGATION
// ==========================================
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading') {
    const data = await chrome.storage.local.get('isSidebarOpen');
    
    if (data.isSidebarOpen && tab.url && tab.url.startsWith('https://app.powerbi.com/')) {
        // ----------------------------------------------------
        // Option 3b: Force sync API pull when navigating in Power BI
        // ----------------------------------------------------
        syncFabricWorkspace();
        
        injectSidebar(tabId);
    }
  }
});

function injectSidebar(tabId) {
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ['content.js']
    }).catch(() => {});
}