// ==================================================
// RCRA BI PORTAL - CONTENT SCRIPT (FINAL)
// ==================================================

// Wrap everything in an IIFE to prevent "Identifier has already been declared" errors
(() => {
    if (window.rcraContentLoaded) return;
    window.rcraContentLoaded = true;

    var pendingLayout = { width: '0px', height: '100vh', push: '0px', side: 'left', isFloating: false };
    let lastCheckedUrl = ""; 
    let urlCheckTimeout;
    let isDevBarActive = false;

    // Listen for the intercepted token from the MAIN world interceptor.js
    window.addEventListener('message', (event) => {
        if (event.source !== window) return;
        if (event.data && event.data.action === 'RCRA_INTERCEPTED_TOKEN') {
            chrome.runtime.sendMessage({ action: 'SAVE_FABRIC_TOKEN', token: event.data.token });
        }
    });

    // ==================================================
    // 1. SIDEBAR & LAYOUT LOGIC
    // ==================================================
    function initSidebar() {
      if (document.getElementById('rcra-sidebar-frame')) return;

      const iframe = document.createElement('iframe');
      iframe.id = 'rcra-sidebar-frame';
      iframe.src = chrome.runtime.getURL('sidebar.html') + '?parent=' + encodeURIComponent(window.location.href);
      
      iframe.style.cssText = `
        position: fixed; top: 0; height: 100vh; border: none; z-index: 2147483648;
        background: transparent !important; color-scheme: normal; transition: all 0.3s ease; 
      `;

      iframe.onload = () => {
        iframe.contentWindow.postMessage({ action: 'REQUEST_LAYOUT' }, '*');
      };

      document.documentElement.appendChild(iframe);
      checkWelcomeStatus();
      injectGlobalCss();
    }

    function applyLayout(data) {
        if (data) pendingLayout = { ...data };
        
        const frame = document.getElementById('rcra-sidebar-frame');
        const htmlNode = document.documentElement;
        const topOffset = isDevBarActive ? '40px' : '0px';

        if (frame) {
            frame.style.width = pendingLayout.width;
            frame.style.height = isDevBarActive ? `calc(100vh - 40px)` : pendingLayout.height;
            frame.style.top = topOffset;
            frame.style.boxShadow = pendingLayout.isFloating ? 'none' : '0 0 10px rgba(0,0,0,0.2)';

            if (pendingLayout.side === 'left') {
                frame.style.left = '0'; frame.style.right = 'auto';
                frame.style.borderRight = '1px solid rgba(0,0,0,0.1)'; frame.style.borderLeft = 'none';
            } else {
                frame.style.right = '0'; frame.style.left = 'auto';
                frame.style.borderLeft = '1px solid rgba(0,0,0,0.1)'; frame.style.borderRight = 'none';
            }
        }

        if (htmlNode) {
            htmlNode.style.transition = 'margin 0.3s ease';
            htmlNode.style.marginTop = topOffset;
            if (pendingLayout.side === 'left') {
                htmlNode.style.marginLeft = pendingLayout.push;
                htmlNode.style.marginRight = '0px';
            } else {
                htmlNode.style.marginRight = pendingLayout.push;
                htmlNode.style.marginLeft = '0px';
            }
        }
    }

    // ==================================================
    // 2. DEV TOP BAR LOGIC
    // ==================================================
    async function showDevBar() {
        if (isDevBarActive) return;
        
        let container = document.getElementById('rcra-dev-wrapper');
        if (!container) {
            const response = await fetch(chrome.runtime.getURL('dev_bar.html'));
            const htmlContent = await response.text();
            
            container = document.createElement('div');
            container.id = "rcra-dev-wrapper";
            container.innerHTML = htmlContent;
            document.body.prepend(container);

            setTimeout(() => {
                const btnClose = document.getElementById('rcra-bar-close');
                if (btnClose) btnClose.addEventListener('click', removeDevBar);
            }, 100);
        }

        setTimeout(() => {
            const bar = document.getElementById('rcra-dev-bar');
            if (bar) bar.classList.add('visible');
        }, 50);

        isDevBarActive = true;
        applyLayout(); 
    }

    function removeDevBar() {
        if (!isDevBarActive) return;
        const bar = document.getElementById('rcra-dev-bar');
        if (bar) bar.classList.remove('visible');
        isDevBarActive = false;
        applyLayout();
        setTimeout(() => {
            const wrapper = document.getElementById('rcra-dev-wrapper');
            if (wrapper) wrapper.remove();
        }, 300);
    }

    // ==================================================
    // 3. AUTOMATIC URL MONITOR & PAGE CSS
    // ==================================================
    async function checkCurrentUrlAndInject() {
        const browserUrl = window.location.href.toLowerCase();
        
        const getReportId = (url) => {
            const match = url.match(/reports\/([a-f0-9\-]{36})/);
            return match ? match[1] : url.split('?')[0]; 
        };

        const currentId = getReportId(browserUrl);
        if (currentId === lastCheckedUrl) return; 
        lastCheckedUrl = currentId;

        const data = await chrome.storage.local.get('cachedMenu');
        let matchFound = false;
        let targetPageCss = null;

        if (data && data.cachedMenu) {
            let menuArray = Array.isArray(data.cachedMenu) ? data.cachedMenu : (data.cachedMenu.menu || []);

            const scanMenu = (items) => {
                for (const item of items) {
                    if (item.url) {
                        const menuId = getReportId(item.url.toLowerCase());
                        if (currentId.includes(menuId) || menuId.includes(currentId)) {
                            if (item.inDevelopment === true || item.inDevelopment === "true") matchFound = true;
                            if (item.pageCss) targetPageCss = item.pageCss;
                        }
                    }
                    if (item.items) scanMenu(item.items);
                }
            };
            scanMenu(menuArray);
        }

        // Toggle Dev Bar
        if (matchFound) {
            console.log("RCRA: Development Report Detected - Showing Bar");
            showDevBar();
        } else {
            if (isDevBarActive) removeDevBar();
        }

        // Handle Page-Specific CSS Injection
        let pageCssTag = document.getElementById('rcra-page-specific-css');
        if (targetPageCss) {
            if (!pageCssTag) {
                pageCssTag = document.createElement('style');
                pageCssTag.id = 'rcra-page-specific-css';
                document.documentElement.appendChild(pageCssTag);
            }
            pageCssTag.innerHTML = targetPageCss;
        } else if (pageCssTag) {
            pageCssTag.remove();
        }
    }

    const urlObserver = new MutationObserver(() => {
        clearTimeout(urlCheckTimeout);
        urlCheckTimeout = setTimeout(checkCurrentUrlAndInject, 2000); 
    });

    urlObserver.observe(document.querySelector('title') || document.documentElement, { 
        subtree: true, childList: true 
    });

    // ==================================================
    // 4. POWER BI DOM ENFORCERS (Icons & CSS)
    // ==================================================
    function forceFavicon() {
        const iconUrl = chrome.runtime.getURL("icon48.png");
        const links = document.querySelectorAll("link[rel*='icon']");
        let found = false;
        links.forEach(link => {
            if (link.href !== iconUrl) link.href = iconUrl;
            found = true;
        });
        if (!found) {
            const link = document.createElement('link');
            link.type = 'image/png'; link.rel = 'icon'; link.href = iconUrl;
            document.head.appendChild(link);
        }
    }

    async function injectGlobalCss() {
        const storageData = await chrome.storage.local.get('cachedSettings');
        if (storageData && storageData.cachedSettings && storageData.cachedSettings.customCss) {
            const cssString = storageData.cachedSettings.customCss;
            
            let styleTag = document.getElementById('rcra-custom-dynamic-css');
            if (!styleTag) {
                styleTag = document.createElement('style');
                styleTag.id = 'rcra-custom-dynamic-css';
                styleTag.innerHTML = cssString;
                document.documentElement.appendChild(styleTag);
            } else if (document.documentElement.lastElementChild !== styleTag) {
                document.documentElement.appendChild(styleTag);
            }
        }
    }

    // ==================================================
    // 5. UTILITIES & INIT
    // ==================================================
    async function checkWelcomeStatus() {
        const data = await chrome.storage.local.get('welcomeDismissed');
        if (data.welcomeDismissed) return;
        createWelcomeOverlay();
    }

    async function createWelcomeOverlay() {
        if (document.getElementById('rcra-welcome-container')) return;
        const response = await fetch(chrome.runtime.getURL('welcome.html'));
        const htmlContent = await response.text();
        const container = document.createElement('div');
        container.id = 'rcra-welcome-container';
        container.innerHTML = htmlContent;
        document.body.appendChild(container);

        const storageData = await chrome.storage.local.get('cachedSettings');
        if (storageData && storageData.cachedSettings) {
            const settings = storageData.cachedSettings;
            
            const wTitle = document.getElementById('dynamic-welcome-title');
            const wDesc = document.getElementById('dynamic-welcome-desc');
            if (wTitle && settings.welcomeTitle) wTitle.innerText = settings.welcomeTitle;
            if (wDesc && settings.welcomeDesc) wDesc.innerText = settings.welcomeDesc;
            
            if (settings.welcomeSteps && settings.welcomeSteps.length > 0) {
                const stepsContainer = document.getElementById('dynamic-welcome-steps');
                if (stepsContainer) {
                    stepsContainer.innerHTML = ''; 
                    
                    settings.welcomeSteps.forEach(step => {
                        const stepHtml = `
                            <div class="rcra-step">
                                <div class="rcra-icon">${step.icon}</div>
                                <div class="rcra-text">
                                    <strong>${step.title}</strong>
                                    <p>${step.text}</p>
                                </div>
                            </div>
                        `;
                        stepsContainer.insertAdjacentHTML('beforeend', stepHtml);
                    });
                }
            }
        }

        setTimeout(() => {
            const closeBtn = document.getElementById('rcra-close-btn');
            if (closeBtn) {
                closeBtn.addEventListener('click', () => {
                    const checkbox = document.getElementById('rcra-dont-show');
                    if (checkbox && checkbox.checked) {
                        chrome.storage.local.set({ welcomeDismissed: true });
                    }
                    const overlay = document.getElementById('rcra-welcome-overlay');
                    if (overlay) {
                        overlay.style.opacity = '0';
                        setTimeout(() => container.remove(), 300);
                    }
                });
            }
        }, 100);
    }

    if (document.documentElement) {
      initSidebar();
      setTimeout(checkCurrentUrlAndInject, 2500);
      
      setInterval(() => {
          forceFavicon();
          injectGlobalCss();
      }, 2000); 
    }

    window.addEventListener('load', () => {
        if (pendingLayout.width !== '0px') applyLayout();
    });

    window.addEventListener('message', (event) => {
        if (event.data.action === 'UPDATE_LAYOUT') applyLayout(event.data);
        if (event.data.action === 'RELOAD_CSS') injectGlobalCss();
    });

    chrome.runtime.onMessage.addListener((request) => {
        if (request.action === 'REMOVE_SIDEBAR') {
            const frame = document.getElementById('rcra-sidebar-frame');
            if (frame) frame.remove();
            document.documentElement.style.marginLeft = '0px';
            document.documentElement.style.marginTop = '0px';
            isDevBarActive = false;
            removeDevBar();
            
            const customCss = document.getElementById('rcra-custom-dynamic-css');
            if (customCss) customCss.remove();
            
            const pageCss = document.getElementById('rcra-page-specific-css');
            if (pageCss) pageCss.remove();
        }
        if (request.action === 'OPEN_SIDEBAR') initSidebar();
    });
})();