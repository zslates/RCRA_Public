// interceptor.js
(function() {
    console.log("RCRA: Token Interceptor Injected into MAIN world!");
    
    function captureToken(headerValue, urlStr) {
        if (!headerValue || !headerValue.startsWith('Bearer ')) return;
        const url = (urlStr || '').toLowerCase();
        
        // ONLY intercept tokens destined for the core Power BI / Fabric APIs
        if (url.includes('powerbi.com') || url.includes('fabric.microsoft.com') || url.includes('analysis.windows.net')) {
            window.postMessage({ action: 'RCRA_INTERCEPTED_TOKEN', token: headerValue.replace('Bearer ', '') }, '*');
        }
    }
    
    // Hijack Fetch API
    const originalFetch = window.fetch;
    window.fetch = async function(...args) {
        try {
            const [resource, config] = args;
            const url = typeof resource === 'string' ? resource : (resource && resource.url ? resource.url : '');
            if (config && config.headers) {
                let authHeader = null;
                if (config.headers instanceof Headers) {
                    authHeader = config.headers.get('Authorization');
                } else if (typeof config.headers === 'object') {
                    const authKey = Object.keys(config.headers).find(k => k.toLowerCase() === 'authorization');
                    if (authKey) authHeader = config.headers[authKey];
                }
                captureToken(authHeader, url);
            }
        } catch(e) {} 
        return originalFetch.apply(this, args);
    };
    
    // Hijack XMLHttpRequest (Need to catch URL from .open first)
    const originalOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url) {
        this._rcraUrl = url;
        return originalOpen.apply(this, arguments);
    };

    const originalSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
    XMLHttpRequest.prototype.setRequestHeader = function(header, value) {
        try {
            if (header.toLowerCase() === 'authorization') {
                captureToken(value, this._rcraUrl);
            }
        } catch(e) {}
        return originalSetRequestHeader.apply(this, arguments);
    };
})();