// ==========================================
// 1. CONFIGURATION
// ==========================================
const MENU_URL = 'https://raw.githubusercontent.com/zslates/RCRA_Public/main/menu2.json';
const SETTINGS_URL = 'https://raw.githubusercontent.com/zslates/RCRA_Public/main/settings.json';

let currentSettings = {};

// ==========================================
// 2. INITIALIZATION & LOGIC
// ==========================================

document.addEventListener('DOMContentLoaded', () => {
  initMenu(); 
});

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') {
    initMenu();
  }
});

// Watch for background local updates to Workspace Data
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local' && (changes.rcraMyWorkspace || changes.rcraPublicWorkspace)) {
        initMenu();
    }
});

function applyGlobalSettings() {
    const titleEl = document.querySelector('.title');
    if (titleEl && currentSettings.portalName) {
        titleEl.textContent = currentSettings.portalName;
    }

    if (currentSettings.customCss) {
        let styleTag = document.getElementById('rcra-custom-dynamic-css');
        if (!styleTag) {
            styleTag = document.createElement('style');
            styleTag.id = 'rcra-custom-dynamic-css';
            document.head.appendChild(styleTag);
        }
        styleTag.innerHTML = currentSettings.customCss;
    }

    const btnLeft = document.getElementById('btn-left');
    const btnRight = document.getElementById('btn-right');
    if (btnLeft && btnRight) {
        const displayVal = currentSettings.showLayoutBtns === false ? 'none' : 'block';
        btnLeft.style.display = displayVal;
        btnRight.style.display = displayVal;
    }

    initSidebar();
}

function initSidebar() {
  const body = document.body;
  const toggleBtn = document.getElementById('sidebar-toggle');
  const hideBtn = document.getElementById('hide-sidebar-btn');
  const floatIcon = document.getElementById('floating-icon');
  const btnLeft = document.getElementById('btn-left');
  const btnRight = document.getElementById('btn-right');

  const updateParentLayout = () => {
    const isFloating = body.classList.contains('floating-mode');
    const isMini = body.classList.contains('mini-mode');
    
    const defaultGlobalSide = currentSettings.defaultSide || 'left';
    const side = localStorage.getItem('sidebar-side') || defaultGlobalSide;
    
    let frameWidth, frameHeight, pagePush;

    if (isFloating) {
        frameWidth = '60px';   
        frameHeight = '60px';  
        pagePush = '0px';      
    } else {
        frameWidth = isMini ? '65px' : '300px';
        frameHeight = '100vh'; 
        pagePush = frameWidth; 
    }

    window.parent.postMessage({ 
      action: 'UPDATE_LAYOUT', 
      width: frameWidth, height: frameHeight, push: pagePush,
      side: side, isFloating: isFloating 
    }, '*');
  };

  if (toggleBtn && !toggleBtn.dataset.listener) {
    toggleBtn.addEventListener('click', () => {
      body.classList.toggle('mini-mode');
      localStorage.setItem('sidebar-mini', body.classList.contains('mini-mode'));
      updateParentLayout();
    });
    toggleBtn.dataset.listener = "true";
  }

  if (hideBtn && !hideBtn.dataset.listener) {
      hideBtn.addEventListener('click', () => {
          body.classList.add('floating-mode');
          localStorage.setItem('sidebar-floating', 'true');
          updateParentLayout();
      });
      hideBtn.dataset.listener = "true";
  }

  if (floatIcon && !floatIcon.dataset.listener) {
      floatIcon.addEventListener('click', () => {
          body.classList.remove('floating-mode');
          localStorage.setItem('sidebar-floating', 'false');
          body.classList.remove('mini-mode');
          localStorage.setItem('sidebar-mini', 'false'); 
          updateParentLayout();
      });
      floatIcon.dataset.listener = "true";
  }

  const setSide = (side) => {
    localStorage.setItem('sidebar-side', side);
    if (btnLeft && btnRight) {
        if (side === 'left') {
          btnLeft.style.background = '#6a4c93'; btnLeft.style.color = 'white';
          btnRight.style.background = 'rgba(0,0,0,0.2)'; btnRight.style.color = '#aea0c0';
        } else {
          btnRight.style.background = '#6a4c93'; btnRight.style.color = 'white';
          btnLeft.style.background = 'rgba(0,0,0,0.2)'; btnLeft.style.color = '#aea0c0';
        }
    }
    updateParentLayout();
  };

  if (btnLeft && btnRight && !btnLeft.dataset.listener) {
    btnLeft.addEventListener('click', () => setSide('left'));
    btnRight.addEventListener('click', () => setSide('right'));
    btnLeft.dataset.listener = "true";
  }

  if (localStorage.getItem('sidebar-floating') === 'true') {
      body.classList.add('floating-mode');
  } else if (localStorage.getItem('sidebar-mini') === 'true' || localStorage.getItem('sidebar-mini') === null) {
      body.classList.add('mini-mode');
      if (localStorage.getItem('sidebar-mini') === null) localStorage.setItem('sidebar-mini', 'true');
  }
  
  const defaultGlobalSide = currentSettings.defaultSide || 'left';
  const savedSide = localStorage.getItem('sidebar-side') || defaultGlobalSide;
  setSide(savedSide);

  window.addEventListener('message', (event) => {
    if (event.data.action === 'REQUEST_LAYOUT') updateParentLayout();
    if (event.data.action === 'RELOAD_MENU') initMenu();
  });

  initInteractions();
}

// ==========================================
// FAVORITES LOGIC
// ==========================================

async function getFavorites() {
    const result = await chrome.storage.sync.get('rcraFavorites');
    return result.rcraFavorites || [];
}

async function toggleFavorite(url) {
    if (!url) return;
    let favs = await getFavorites();
    if (favs.includes(url)) favs = favs.filter(u => u !== url); 
    else favs.push(url); 
    
    await chrome.storage.sync.set({ rcraFavorites: favs });
    initMenu(); 
}

function findItemByUrl(items, url) {
    for (const item of items) {
        if (item.url === url) return item;
        if (item.items && item.items.length > 0) {
            const found = findItemByUrl(item.items, url);
            if (found) return found;
        }
    }
    return null;
}

// ==========================================
// INIT MENU
// ==========================================
let isRenderingMenu = false; // Prevents race conditions during simultaneous reloads

async function initMenu() {
  if (isRenderingMenu) return;
  isRenderingMenu = true;

  try {
      const container = document.getElementById('nav-tree-container');
      let currentData = [];

      try {
        const stored = await chrome.storage.local.get(['cachedMenu', 'cachedSettings']);
        if (stored.cachedMenu) currentData = stored.cachedMenu;
        if (stored.cachedSettings) currentSettings = stored.cachedSettings;
      } catch (e) {}

      try {
        const [menuRes, settingsRes] = await Promise.all([
            fetch(MENU_URL + '?t=' + new Date().getTime()),
            fetch(SETTINGS_URL + '?t=' + new Date().getTime())
        ]);

        if (menuRes.ok) {
            const liveMenu = await menuRes.json();
            if (liveMenu.menu && !Array.isArray(liveMenu)) {
                currentData = liveMenu.menu;
                if (liveMenu.settings && (!settingsRes.ok)) currentSettings = liveMenu.settings;
            } else {
                currentData = liveMenu;
            }
            await chrome.storage.local.set({ cachedMenu: currentData });
        }

        if (settingsRes.ok) {
            const liveSettings = await settingsRes.json();
            currentSettings = liveSettings;
            await chrome.storage.local.set({ cachedSettings: currentSettings });
        }
      } catch (e) { console.warn("Fetch failed, using cache"); }

      applyGlobalSettings();

      const favs = await getFavorites();
      let finalData = JSON.parse(JSON.stringify(currentData)); 

      // 1. Fetch Workspaces from Storage
      const workspaceData = await chrome.storage.local.get(['rcraMyWorkspace', 'rcraPublicWorkspace']);
      const personalWs = workspaceData.rcraMyWorkspace || [];
      const publicWs = workspaceData.rcraPublicWorkspace || [];

      // 2. Attach dynamic workspace content to nodes mapped in the Menu Editor
      function attachWorkspaces(items) {
          items.forEach(item => {
              if (item.type === 'workspace') {
                  item.items = item.workspaceId === '8d966faa-0abd-4694-b3b0-be795b35ef5e' ? publicWs : personalWs;
                  item._isWorkspaceFolder = true; 
              }
              if (item.items) attachWorkspaces(item.items);
          });
      }
      attachWorkspaces(finalData);

      // Safety Fallback: Prepend them automatically if they haven't been added to the Menu Editor yet
      const hasPersonal = JSON.stringify(finalData).includes('"workspaceId":"personal"');
      const hasPublic = JSON.stringify(finalData).includes('"8d966faa-0abd-4694-b3b0-be795b35ef5e"');

      if (!hasPublic && publicWs.length > 0) {
          finalData.unshift({ name: "Public Workspace", category: "Public Workspace", type: "workspace", workspaceId: "8d966faa-0abd-4694-b3b0-be795b35ef5e", items: publicWs, _isWorkspaceFolder: true });
      }
      if (!hasPersonal && personalWs.length > 0) {
          finalData.unshift({ name: "My Workspace", category: "My Workspace", type: "workspace", workspaceId: "personal", items: personalWs, _isWorkspaceFolder: true });
      }

      // 3. Favorites
      if (favs.length > 0) {
          const favItems = [];
          favs.forEach(favUrl => {
              const original = findItemByUrl(finalData, favUrl);
              if (original) favItems.push({ ...original }); 
          });

          if (favItems.length > 0) {
              finalData.unshift({
                  name: "Favorites", category: "Favorites",
                  items: favItems, _isFavFolder: true 
              }); 
          }
      }

      renderMenu(finalData, container, favs);
  } finally {
      isRenderingMenu = false;
  }
}

// ==========================================
// 3. RENDER LOGIC
// ==========================================
function renderMenu(menuData, container, favoritesList) {
  
  // CAPTURE WHICH FOLDERS ARE CURRENTLY OPEN BEFORE CLEARING
  const openFolders = new Set();
  container.querySelectorAll('.nav-group.expanded').forEach(g => {
      const label = g.getAttribute('data-search-label');
      if (label) openFolders.add(label);
  });
  
  container.innerHTML = '';
  const urlParams = new URLSearchParams(window.location.search);
  const rawParentUrl = urlParams.get('parent') || '';
  const currentUrl = rawParentUrl.toLowerCase().replace(/\/$/, "");

  function buildNode(item, isRoot) {
    if (item.isHidden) return document.createElement('div');

    const labelText = item.category || item.name || 'Untitled';
    
    const hasChildren = item.items && Array.isArray(item.items);
    const isFolder = (item.items !== undefined || item.type === 'workspace'); 
    const isFavFolder = item._isFavFolder === true;
    const isWorkspaceFolder = item._isWorkspaceFolder === true;
    const isDev = (item.inDevelopment === true || item.inDevelopment === "true");

    const itemDiv = document.createElement('div');
    let isActive = false;
    
    if (item.url) {
        let itemUrlFull = item.url;
        if (!itemUrlFull.startsWith('http') && !itemUrlFull.startsWith('//') && !itemUrlFull.startsWith('chrome')) {
             itemUrlFull = chrome.runtime.getURL(itemUrlFull);
        }
        const cleanItemUrl = itemUrlFull.toLowerCase().replace(/\/$/, "");
        if (cleanItemUrl.length > 5 && currentUrl.includes(cleanItemUrl)) {
            isActive = true;
        }
    }
    const activeClass = isActive ? 'active-selection' : '';

    if (isFolder) {
        itemDiv.className = 'nav-group';
        
        if (isFavFolder) itemDiv.classList.add('fav-group');
        if (isWorkspaceFolder && isRoot) itemDiv.classList.add('workspace-group'); // Mark workspaces for CSS targets
        
        itemDiv.setAttribute('data-search-label', labelText.toLowerCase());
        
        const header = document.createElement('div');
        header.className = 'nav-item folder';
        header.title = labelText;
        
        const fColor = item.color || "currentColor";
        const fTextStyle = item.color ? `color: ${item.color}; font-weight: 500;` : "";
        
        let folderIcon = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="${fColor}" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>`;
        
        if (isFavFolder) {
            folderIcon = '<svg width="16" height="16" viewBox="0 0 24 24" fill="#FFD700" stroke="#FFD700" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>';
        } else if (isWorkspaceFolder && isRoot) {
            folderIcon = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path><polyline points="17 21 17 13 7 13 7 21"></polyline><polyline points="7 3 7 8 15 8"></polyline></svg>';
        }

        let actionBtnHTML = '';
        
        if (item.folderUrl) {
            actionBtnHTML += `
            <div class="folder-url-action" data-url="${item.folderUrl}" title="Open Folder Link" style="color: var(--text-secondary); cursor: pointer;">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
            </div>`;
        }

        if (isWorkspaceFolder && isRoot) {
            actionBtnHTML += `
            <div class="workspace-action-refresh" title="Sync / Refresh Workspace" style="cursor: pointer;">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="23 4 23 10 17 10"></polyline>
                    <polyline points="1 20 1 14 7 14"></polyline>
                    <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
                </svg>
            </div>`;
        }

        header.innerHTML = `
            <div class="left-col">
              <svg class="chevron-folder" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="9 18 15 12 9 6"></polyline></svg>
              <div class="icon-box">
                 ${folderIcon}
              </div>
              <span class="label" style="${fTextStyle}">${labelText}</span>
            </div>
            <div style="display: flex; align-items: center; gap: 12px;">${actionBtnHTML}</div>
        `;
            
        const subMenu = document.createElement('div');
        subMenu.className = 'sub-menu';
        if (hasChildren && item.items.length > 0) {
            item.items.forEach(child => subMenu.appendChild(buildNode(child, false)));
        }
        
        // CHECK IF THIS FOLDER WAS OPEN BEFORE THE RELOAD
        const wasOpen = openFolders.has(labelText.toLowerCase());
        
        if (subMenu.querySelector('.active-selection') || item._expanded || wasOpen) {
            itemDiv.classList.add('expanded');
            header.classList.add('active');
            header.querySelector('.chevron-folder').innerHTML = '<polyline points="6 9 12 15 18 9"></polyline>';
        }
        
        if (isWorkspaceFolder && isRoot) {
            const refreshBtn = header.querySelector('.workspace-action-refresh');
            if (refreshBtn) {
                refreshBtn.addEventListener('click', (e) => {
                    e.stopPropagation(); e.preventDefault();
                    
                    // Trigger spin animation visually right now
                    const svg = refreshBtn.querySelector('svg');
                    if (svg) {
                        svg.classList.add('spin-anim');
                        setTimeout(() => svg.classList.remove('spin-anim'), 3000); // Failsafe removal
                    }
                    
                    // Force the menu open instantly upon click
                    itemDiv.classList.add('expanded');
                    header.classList.add('active');
                    const chevron = header.querySelector('.chevron-folder');
                    if (chevron) chevron.innerHTML = '<polyline points="6 9 12 15 18 9"></polyline>';
                    
                    // Tell background to fetch. The storage listener will trigger a seamless re-render!
                    chrome.runtime.sendMessage({ action: 'FORCE_SYNC' });
                });
            }
        }

        const urlBtn = header.querySelector('.folder-url-action');
        if (urlBtn) {
            urlBtn.addEventListener('click', (e) => {
                e.stopPropagation(); e.preventDefault();
                window.open(urlBtn.getAttribute('data-url'), '_blank');
                
                // Force the sidebar into collapsed (mini) mode
                if (!document.body.classList.contains('mini-mode')) {
                    const toggleBtn = document.getElementById('sidebar-toggle');
                    if (toggleBtn) toggleBtn.click();
                }
            });
            urlBtn.addEventListener('mouseenter', () => urlBtn.style.color = '#fff');
            urlBtn.addEventListener('mouseleave', () => urlBtn.style.color = 'var(--text-secondary)');
        }

        itemDiv.appendChild(header);
        itemDiv.appendChild(subMenu);
        return itemDiv;
    } else {
        let iconSvg = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#F2C811" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>';
        
        if (isDev) {
             iconSvg = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#cf6679" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>';
        } else if (labelText === "Home") {
            iconSvg = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>';
        } else if (item.linkType === 'excel') {
             iconSvg = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#4caf50" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>';
        }

        itemDiv.className = `nav-item report ${activeClass}`;
        itemDiv.setAttribute('data-url', item.url);
        itemDiv.setAttribute('data-search-label', labelText.toLowerCase());
        
        if(isDev) itemDiv.setAttribute('data-dev', 'true');
        if(item.openNewTab) itemDiv.setAttribute('data-new-tab', 'true');
        
        itemDiv.title = labelText;
        
        const isFav = favoritesList.includes(item.url);
        const starClass = isFav ? 'fav-active' : '';
        const starFill = isFav ? '#FFD700' : 'none';
        const starStroke = isFav ? '#FFD700' : 'currentColor';
        const actionBtnHTML = `
        <div class="fav-action ${starClass}" title="${isFav ? 'Remove Favorite' : 'Add to Favorites'}">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="${starFill}" stroke="${starStroke}" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
        </div>
        `;

        itemDiv.innerHTML = `
          <div class="left-col">
              <div class="chevron-folder"></div> 
              <div class="icon-box report-icon">
                ${iconSvg}
              </div>
              <span class="label">${labelText}</span>
          </div>
          ${actionBtnHTML}
        `;
        
        const favBtn = itemDiv.querySelector('.fav-action');
        favBtn.addEventListener('click', (e) => {
            e.stopPropagation(); e.preventDefault();
            toggleFavorite(item.url);
        });
        
        return itemDiv;
    }
  }
  
  menuData.forEach(rootItem => container.appendChild(buildNode(rootItem, true)));
  
  // Inject the border lines strictly via JS to bypass the CSS first-of-type limitations
  const workspaces = container.querySelectorAll('.workspace-group');
  if (workspaces.length > 0) {
      workspaces[0].classList.add('workspace-first');
      workspaces[workspaces.length - 1].classList.add('workspace-last');
  }
}

// ==========================================
// 4. MASTER INTERACTION LOGIC
// ==========================================
function initInteractions() {
    const navContainer = document.getElementById('nav-tree-container');
    if (navContainer && !navContainer.dataset.listener) {
        navContainer.addEventListener('click', (e) => {
            const folder = e.target.closest('.nav-item.folder');
            if (folder) {
                // Ignore clicks if they specifically clicked the refresh or url buttons
                if (e.target.closest('.workspace-action-refresh') || e.target.closest('.folder-url-action')) return;
                
                e.preventDefault(); e.stopPropagation();
                const parentGroup = folder.closest('.nav-group');
                if (parentGroup.classList.contains('expanded')) {
                    parentGroup.classList.remove('expanded');
                    const chevron = folder.querySelector('.chevron-folder');
                    if(chevron) chevron.innerHTML = '<polyline points="9 18 15 12 9 6"></polyline>';
                } else {
                    parentGroup.classList.add('expanded');
                    const chevron = folder.querySelector('.chevron-folder');
                    if(chevron) chevron.innerHTML = '<polyline points="6 9 12 15 18 9"></polyline>';
                }
                return;
            }

            const reportItem = e.target.closest('.nav-item.report');
            if (reportItem) {
                if (e.target.closest('.fav-action')) return;
                
                e.preventDefault(); e.stopPropagation();

                let url = reportItem.getAttribute('data-url');
                let isNewTab = reportItem.getAttribute('data-new-tab') === 'true';

                if (url && url !== "undefined" && url !== "#") {
                    if (!url.startsWith('http') && !url.startsWith('//') && !url.startsWith('chrome-extension')) {
                        url = chrome.runtime.getURL(url);
                    }
                    if (isNewTab) {
                        window.open(url, '_blank');
                    } else {
                        localStorage.setItem('sidebar-floating', 'false');
                        localStorage.setItem('sidebar-mini', 'true');
                        window.parent.location.href = url;
                    }
                }
            }
        });
        navContainer.dataset.listener = "true";
    }

    const searchInput = document.querySelector('.search-box input');
    if (searchInput && !searchInput.dataset.listener) {
        searchInput.addEventListener('input', (e) => {
          const term = e.target.value.toLowerCase().trim();
          const allGroups = document.querySelectorAll('.nav-group');
          const allReports = document.querySelectorAll('.nav-item.report');
          if (term === '') {
            allGroups.forEach(g => {
                g.style.display = 'block';
                if (!g.querySelector('.active-selection')) g.classList.remove('expanded'); 
            });
            allReports.forEach(r => r.style.display = 'flex');
            return;
          }
          allGroups.forEach(g => g.style.display = 'none');
          allReports.forEach(r => r.style.display = 'none');
          const matches = [];
          allReports.forEach(r => { if (r.getAttribute('data-search-label').includes(term)) matches.push(r); });
          allGroups.forEach(g => { if (g.getAttribute('data-search-label').includes(term)) matches.push(g); });
          matches.forEach(match => {
              match.style.display = (match.classList.contains('nav-group')) ? 'block' : 'flex';
              if (match.classList.contains('nav-group')) {
                 match.classList.add('expanded');
                 const children = match.querySelectorAll(':scope > .sub-menu > .nav-item, :scope > .sub-menu > .nav-group');
                 children.forEach(c => c.style.display = (c.classList.contains('nav-group')) ? 'block' : 'flex');
              }
              let parent = match.parentElement.closest('.nav-group');
              while (parent) {
                  parent.style.display = 'block';
                  parent.classList.add('expanded');
                  parent = parent.parentElement.closest('.nav-group');
              }
          });
        });
        searchInput.dataset.listener = "true";
    }
}