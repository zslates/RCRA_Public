// ==================================================
// RCRA BI PORTAL - BACKGROUND SERVICE WORKER
// ==================================================

// Config: Needs to match sidebar.js
const MENU_URL = 'https://raw.githubusercontent.com/zslates/RCRA_Public/main/menu2.json';
const DEFAULT_HOME = "https://app.powerbi.com/home";

// ==========================================
// 1. HELPER: DYNAMIC HOME URL
// ==========================================
async function getDynamicHomeUrl() {
  try {
    const stored = await chrome.storage.local.get('cachedMenu');
    let data = stored.cachedMenu;

    if (!data || data.length === 0) {
       const res = await fetch(MENU_URL);
       data = await res.json();
       await chrome.storage.local.set({ cachedMenu: data });
    }

    let menuArray = Array.isArray(data) ? data : (data.menu || []);

    const findFirstLink = (items) => {
        for (const item of items) {
            if (item.url && item.url !== "#") return item.url;
            if (item.items && item.items.length > 0) {
                const found = findFirstLink(item.items);
                if (found) return found;
            }
        }
        return null;
    };

    const firstUrl = findFirstLink(menuArray);
    
    if (firstUrl) {
         if (!firstUrl.startsWith('http') && !firstUrl.startsWith('//')) {
             return DEFAULT_HOME; 
         }
         return firstUrl;
    }

  } catch (e) {
    console.warn("Failed to determine dynamic home, using default.", e);
  }
  return DEFAULT_HOME;
}

// ==========================================
// 2. FABRIC API: MY WORKSPACE SYNC
// ==========================================

async function getFabricToken() {
    const data = await chrome.storage.local.get('fabricToken');
    return data.fabricToken || null;
}

let isSyncing = false; // Prevents concurrent sync overlapping

async function syncFabricWorkspace() {
    if (isSyncing) return;
    isSyncing = true;
    
    console.log("RCRA Sync: Starting sync sequence...");
    try {
        const token = await getFabricToken();
        if (!token) {
            console.log("RCRA Sync: No intercepted token available yet.");
            return;
        }

        const headers = { 'Authorization': `Bearer ${token}` };

        async function fetchWorkspaceData(wsId) {
            const [foldersRes, reportsRes] = await Promise.all([
                fetch(`https://api.fabric.microsoft.com/v1/workspaces/${wsId}/folders`, { headers }),
                fetch(`https://api.fabric.microsoft.com/v1/workspaces/${wsId}/items?type=Report`, { headers })
            ]);

            // STRICT VALIDATION: If the API fails, throw an error to protect the cache from being wiped
            if (!foldersRes.ok || !reportsRes.ok) {
                throw new Error(`API Sync Failed for ${wsId}. Folders: ${foldersRes.status}, Reports: ${reportsRes.status}`);
            }

            const foldersData = await foldersRes.json();
            const reportsData = await reportsRes.json();

            const folderMap = {};
            const rootNodes = [];

            (foldersData.value || []).forEach(f => {
                folderMap[f.id] = { 
                    name: f.displayName, category: f.displayName, 
                    items: [], id: f.id, parentId: f.parentFolderId,
                    _isWorkspaceFolder: true, _expanded: false 
                };
            });

            (reportsData.value || []).forEach(r => {
                const reportItem = { 
                    name: r.displayName, 
                    url: `https://app.powerbi.com/groups/${wsId === 'personal' ? 'me' : wsId}/reports/${r.id}`, 
                    linkType: 'report', _isWorkspaceItem: true 
                };
                if (r.folderId && folderMap[r.folderId]) folderMap[r.folderId].items.push(reportItem);
                else rootNodes.push(reportItem);
            });

            Object.values(folderMap).forEach(f => {
                const parentId = f.parentId;
                delete f.id; delete f.parentId;
                if (parentId && folderMap[parentId]) folderMap[parentId].items.push(f);
                else rootNodes.push(f);
            });

            function sortTree(nodes) {
                nodes.sort((a, b) => (a.name || a.category || "").toLowerCase().localeCompare((b.name || b.category || "").toLowerCase()));
                nodes.forEach(n => { if (n.items) sortTree(n.items); });
            }
            sortTree(rootNodes);
            return rootNodes;
        }

        const wsRes = await fetch('https://api.fabric.microsoft.com/v1/workspaces', { headers });
        if (!wsRes.ok) throw new Error(`Fabric API rejected token. Status: ${wsRes.status}`);
        const wsData = await wsRes.json();
        const personalWs = wsData.value.find(ws => ws.type === 'Personal');

        let updates = {};

        // Fetch Personal
        if (personalWs) {
            try { 
                updates.rcraMyWorkspace = await fetchWorkspaceData(personalWs.id); 
            } catch(e) { console.warn("RCRA Sync Personal Workspace skipped:", e.message); }
        }

        // Stagger the calls to prevent Fabric API rate limiting
        await new Promise(resolve => setTimeout(resolve, 300));

        // Fetch Public
        try { 
            updates.rcraPublicWorkspace = await fetchWorkspaceData('8d966faa-0abd-4694-b3b0-be795b35ef5e'); 
        } catch (e) { console.warn("RCRA Sync Public Workspace skipped:", e.message); }

        // Only save what successfully returned data
        if (Object.keys(updates).length > 0) {
            await chrome.storage.local.set(updates);
            console.log("RCRA Sync: Workspace trees successfully compiled and saved!");
        }

    } catch (error) {
        console.error("RCRA Sync Fatal Error:", error.message);
    } finally {
        isSyncing = false; // Release the lock
    }
}

// ----------------------------------------------------
// Option 4: Background Polling dropped to 1 Minute
// ----------------------------------------------------
chrome.alarms.create("syncFabricData", { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "syncFabricData") {
        syncFabricWorkspace();
    }
});


// ==========================================
// 3. LISTENER: MESSAGE BUS (Tokens & Identity)
// ==========================================
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // Catch the intercepted token from content.js
    if (request.action === 'SAVE_FABRIC_TOKEN' && request.token) {
        chrome.storage.local.get('fabricToken', (data) => {
            // Only update and re-sync if the token has actually changed
            if (data.fabricToken !== request.token) {
                chrome.storage.local.set({ fabricToken: request.token }, () => {
                    console.log("RCRA Sync: Fresh token saved. Triggering sync API sequence.");
                    syncFabricWorkspace(); 
                });
            }
        });
    }
    
    // Force manual sync from UI
    if (request.action === 'FORCE_SYNC') {
        syncFabricWorkspace();
    }

    // Dev Bar Test Hook
    if (request.action === 'GET_USER_IDENTITY') {
        chrome.identity.getProfileUserInfo((userInfo) => {
            sendResponse({ email: userInfo.email || "" });
        });
        return true; 
    }
});

// ==========================================
// 4. LISTENER: ON INSTALL
// ==========================================
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === "install") {
    const targetUrl = await getDynamicHomeUrl();
    chrome.tabs.create({ url: targetUrl });
    chrome.storage.local.set({ isSidebarOpen: true });
    syncFabricWorkspace(); 
  }
});

// ==========================================
// 5. LISTENER: TOGGLE CLICK
// ==========================================
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.url.includes("app.powerbi.com")) return;

  const data = await chrome.storage.local.get('isSidebarOpen');
  const newState = !data.isSidebarOpen;
  await chrome.storage.local.set({ isSidebarOpen: newState });

  if (newState) {
    // ----------------------------------------------------
    // Option 3a: Force sync API pull when sidebar opens
    // ----------------------------------------------------
    syncFabricWorkspace();

    const homeUrl = await getDynamicHomeUrl();
    const currentClean = tab.url.toLowerCase().replace(/\/$/, "");
    const homeClean = homeUrl.toLowerCase().replace(/\/$/, "");
    
    if (!currentClean.includes(homeClean)) {
        await chrome.tabs.update(tab.id, { url: homeUrl });
    } else {
        try {
            await chrome.tabs.sendMessage(tab.id, { action: 'OPEN_SIDEBAR' });
        } catch (err) {
            injectSidebar(tab.id);
        }
    }
  } else {
    try {
      await chrome.tabs.sendMessage(tab.id, { action: 'REMOVE_SIDEBAR' });
    } catch (err) { }
  }
});

// ==========================================
// 6. LISTENER: PAGE NAVIGATION
// ==========================================
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading') {
    const data = await chrome.storage.local.get('isSidebarOpen');
    
    if (data.isSidebarOpen && tab.url && tab.url.startsWith('https://app.powerbi.com/')) {
        // ----------------------------------------------------
        // Option 3b: Force sync API pull when navigating in Power BI
        // ----------------------------------------------------
        syncFabricWorkspace();
        
        injectSidebar(tabId);
    }
  }
});

function injectSidebar(tabId) {
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ['content.js']
    }).catch(() => {});
}